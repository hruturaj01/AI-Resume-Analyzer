export default function ReportLoading() {
  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-8">
      <div className="card p-6">
        <div className="h-3 w-32 rounded skeleton" />
        <div className="mt-4 h-8 w-2/3 rounded skeleton" />
        <div className="mt-3 h-3 w-full max-w-xl rounded skeleton" />
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {[0, 1, 2].map((index) => (
            <div key={index} className="card-flat h-20 skeleton" />
          ))}
        </div>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="card h-64 skeleton" />
        <div className="card h-64 skeleton" />
      </div>
      <p className="mt-6 text-center font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/35">
        Loading your placement report…
      </p>
    </div>
  );
}
