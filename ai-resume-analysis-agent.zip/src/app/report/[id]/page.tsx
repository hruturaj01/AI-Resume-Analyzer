import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ReportView } from "@/components/report-view";
import { SiteFooter, SiteNav } from "@/components/site-nav";
import { getAnalysis } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  try {
    const result = await getAnalysis(id);
    if (!result) return { title: "Report not found — Placemate" };
    return {
      title: `${result.analysis.candidateName ?? "Resume"} · ${result.analysis.targetRoleTitle} report — Placemate`,
      description: result.analysis.report.headline,
    };
  } catch {
    return { title: "Placement report — Placemate" };
  }
}

export default async function ReportPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ fresh?: string }>;
}) {
  const [{ id }, query] = await Promise.all([params, searchParams]);

  let result: Awaited<ReturnType<typeof getAnalysis>> = null;
  try {
    result = await getAnalysis(id);
  } catch {
    result = null;
  }
  if (!result) notFound();

  const createdAtLabel = new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  }).format(result.analysis.createdAt);

  return (
    <>
      <SiteNav />
      <main>
        <ReportView
          publicId={result.analysis.publicId}
          createdAtLabel={createdAtLabel}
          report={result.analysis.report}
          tasks={result.tasks.map((task) => ({
            id: task.id,
            phaseIndex: task.phaseIndex,
            taskIndex: task.taskIndex,
            title: task.title,
            done: task.done,
          }))}
          fresh={query.fresh === "1"}
        />
      </main>
      <SiteFooter />
    </>
  );
}
