import Link from "next/link";
import { SiteFooter, SiteNav } from "@/components/site-nav";
import { RolesExplorer } from "@/components/roles-explorer";
import { ROLES } from "@/lib/roles";

export const metadata = {
  title: "Placement role tracks — Placemate",
  description:
    "Explore 12 tech placement tracks: required skills, salary bands, portfolio projects and interview focus areas.",
};

export default function RolesPage() {
  return (
    <>
      <SiteNav />
      <main className="mx-auto w-full max-w-6xl px-5 py-12">
        <div className="max-w-3xl">
          <p className="label">Placement tracks · {ROLES.length} roles</p>
          <h1 className="mt-3 text-[clamp(2rem,4.4vw,3rem)] font-extrabold leading-[1.02] tracking-[-0.045em] text-white">
            Pick the track. Then let the agent teach you{" "}
            <span className="bg-gradient-to-r from-accent-soft to-mint bg-clip-text text-transparent">exactly</span> what
            to build.
          </h1>
          <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-white/55">
            Every track lists the core requirements hiring panels screen for, realistic salary bands, two portfolio
            projects that convert, and the interview areas you will be drilled on.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Link href="/#analyzer" className="btn-primary">
              Analyze against my resume →
            </Link>
            <Link href="/dashboard" className="btn-ghost">
              My saved reports
            </Link>
          </div>
        </div>

        <div className="mt-9">
          <RolesExplorer />
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
