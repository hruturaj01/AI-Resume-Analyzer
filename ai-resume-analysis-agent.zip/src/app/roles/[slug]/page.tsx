import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SiteFooter, SiteNav } from "@/components/site-nav";
import { getRole, ROLES } from "@/lib/roles";

export function generateStaticParams() {
  return ROLES.map((role) => ({ slug: role.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const role = getRole(slug);
  if (!role) return { title: "Role track not found — Placemate" };
  return {
    title: `${role.title} placement roadmap — Placemate`,
    description: `${role.title}: core skills, salary bands, portfolio projects and the interview plan. ${role.tagline}`,
  };
}

export default async function RolePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const role = getRole(slug);
  if (!role) notFound();

  const phases = [
    {
      label: "01",
      title: "Fundamentals",
      timeframe: "Weeks 1–3",
      body: `Get productive in ${role.coreSkills.slice(0, 3).join(", ")} by building small demos, not watching tutorials. Rewrite your resume with measurable outcomes.`,
      outcome: `You can explain and demo ${role.coreSkills.slice(0, 2).join(" + ")} without notes.`,
    },
    {
      label: "02",
      title: "Proof of work",
      timeframe: "Weeks 4–7",
      body: `Ship the two projects below, deploy them publicly and document the decisions in the READMEs. Add ${role.bonusSkills[0] ?? role.coreSkills[0]} as a differentiator.`,
      outcome: "A recruiter can validate your ability in one click.",
    },
    {
      label: "03",
      title: "Interview conditioning",
      timeframe: "Weeks 8–10",
      body: `Drill ${role.interviewTopics.slice(0, 2).join(" and ")}, then run two recorded mock interviews and rebuild weak answers.`,
      outcome: "Structured answers under time pressure.",
    },
    {
      label: "04",
      title: "Placement sprint",
      timeframe: "Weeks 11–12",
      body: "Shortlist 40 companies in the right band, work referrals before portals, and apply with a tailored resume each week.",
      outcome: `Interviews and a competitive ${role.title} offer.`,
    },
  ];

  return (
    <>
      <SiteNav />
      <main className="mx-auto w-full max-w-6xl px-5 py-10">
        <nav className="flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.12em] text-white/35">
          <Link href="/" className="hover:text-white/70">Home</Link>
          <span aria-hidden="true">/</span>
          <Link href="/roles" className="hover:text-white/70">Role tracks</Link>
          <span aria-hidden="true">/</span>
          <span className="text-white/60">{role.title}</span>
        </nav>

        <div className="mt-5 grid gap-6 lg:grid-cols-[1.4fr_0.6fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip chip-accent">{role.category}</span>
              <span className="chip">{role.demand} demand</span>
            </div>
            <h1 className="mt-3 text-[clamp(2rem,4.4vw,3rem)] font-extrabold leading-[1.03] tracking-[-0.045em] text-white">
              {role.title}
            </h1>
            <p className="mt-2 text-[15px] font-medium text-accent/80">{role.tagline}</p>
            <p className="mt-3 max-w-2xl text-[13.5px] leading-relaxed text-white/58">{role.summary}</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Link href={`/?role=${role.slug}#analyzer`} className="btn-primary">
                Analyze my resume for this track →
              </Link>
              <Link href="/roles" className="btn-ghost">
                Compare other tracks
              </Link>
            </div>
          </div>

          <aside className="card h-fit p-5">
            <p className="label">Track facts</p>
            <dl className="mt-3 space-y-3">
              {[
                { label: "India band", value: role.salaryIndia },
                { label: "Global band", value: role.salaryGlobal },
                { label: "Demand", value: role.demand },
                { label: "Core skills", value: `${role.coreSkills.length} requirements` },
                { label: "Interview areas", value: `${role.interviewTopics.length} focus topics` },
              ].map((item) => (
                <div key={item.label} className="flex items-start justify-between gap-3 border-b border-white/6 pb-2.5 last:border-0 last:pb-0">
                  <dt className="text-[11.5px] text-white/40">{item.label}</dt>
                  <dd className="text-right text-[12.5px] font-semibold text-white/85">{item.value}</dd>
                </div>
              ))}
            </dl>
            <a
              href={`https://roadmap.sh/${role.roadmapSlug}`}
              target="_blank"
              rel="noreferrer noopener"
              className="btn-ghost mt-4 w-full text-[11.5px]"
            >
              Visual skill roadmap ↗
            </a>
          </aside>
        </div>

        <section className="mt-9 grid gap-3 sm:grid-cols-2">
          <div className="card p-5">
            <p className="label">Core requirements</p>
            <ul className="mt-3 grid gap-1.5 sm:grid-cols-2">
              {role.coreSkills.map((skill, index) => (
                <li key={skill} className="flex items-center gap-2.5 rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
                  <span className="font-mono text-[9.5px] text-accent/60">{String(index + 1).padStart(2, "0")}</span>
                  <span className="text-[12.5px] text-white/80">{skill}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="card p-5">
            <p className="label">Differentiators</p>
            <p className="mt-1.5 text-[12px] leading-relaxed text-white/40">
              Skills that push you into the top quartile of applicants for this track.
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {role.bonusSkills.map((skill) => (
                <span key={skill} className="chip chip-accent text-[11px]">
                  {skill}
                </span>
              ))}
            </div>
            <p className="label mt-5">Interview focus</p>
            <ul className="mt-2 space-y-1.5">
              {role.interviewTopics.map((topic) => (
                <li key={topic} className="flex items-start gap-2 text-[12.5px] text-white/65">
                  <span className="mt-0.5 text-[10px] text-accent">▸</span>
                  {topic}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mt-9">
          <p className="label">Portfolio plays</p>
          <h2 className="mt-2 text-[22px] font-extrabold tracking-[-0.03em] text-white">Two projects that get you shortlisted</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {role.projects.map((project, index) => (
              <div key={project.title} className="card p-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[15px] font-bold tracking-[-0.02em] text-white">{project.title}</h3>
                  <span className="font-mono text-[10px] text-accent/50">0{index + 1}</span>
                </div>
                <p className="mt-2 text-[12.5px] leading-relaxed text-white/55">{project.summary}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {project.stack.map((item) => (
                    <span key={item} className="chip text-[10.5px]">{item}</span>
                  ))}
                </div>
                <p className="mt-3 border-t border-white/8 pt-3 text-[11.5px] leading-relaxed text-accent/75">
                  {project.impact}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-9">
          <p className="label">12-week track plan</p>
          <h2 className="mt-2 text-[22px] font-extrabold tracking-[-0.03em] text-white">The shape of the roadmap</h2>
          <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-white/45">
            This is the default sequence. Running your resume through the agent personalises it with your own gaps,
            deadline and role match.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {phases.map((phase) => (
              <div key={phase.label} className="card p-5">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10.5px] tracking-[0.16em] text-accent/70">{phase.label}</span>
                  <span className="chip text-[9.5px] text-white/45">{phase.timeframe}</span>
                </div>
                <h3 className="mt-2.5 text-[14px] font-bold text-white">{phase.title}</h3>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-white/48">{phase.body}</p>
                <p className="mt-3 border-t border-white/8 pt-2.5 text-[11px] leading-relaxed text-accent/70">
                  {phase.outcome}
                </p>
              </div>
            ))}
          </div>
        </section>

        <div className="mt-10 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-accent/20 bg-accent/8 px-5 py-5">
          <div>
            <p className="text-[15px] font-bold tracking-[-0.02em] text-white">How close are you to this track today?</p>
            <p className="mt-1 text-[12.5px] text-white/55">
              The agent scores your resume against all {ROLES.length} tracks, then builds the plan around your gaps.
            </p>
          </div>
          <Link href={`/?role=${role.slug}#analyzer`} className="btn-primary">
            Run my analysis →
          </Link>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
