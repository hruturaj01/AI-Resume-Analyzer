import Link from "next/link";
import { SiteFooter, SiteNav } from "@/components/site-nav";

export default function NotFound() {
  return (
    <>
      <SiteNav />
      <main className="mx-auto flex w-full max-w-3xl flex-col items-center px-5 py-24 text-center">
        <p className="label">404 · report not found</p>
        <h1 className="mt-3 text-[clamp(1.8rem,4vw,2.8rem)] font-extrabold tracking-[-0.04em] text-white">
          This report has been deleted or never existed.
        </h1>
        <p className="mt-3 max-w-md text-[13.5px] leading-relaxed text-white/50">
          Reports are saved with a private link. If you removed this one, run a fresh analysis — it takes about thirty
          seconds.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2.5">
          <Link href="/#analyzer" className="btn-primary">
            Analyze my resume →
          </Link>
          <Link href="/dashboard" className="btn-ghost">
            View saved reports
          </Link>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
