import { eq } from "drizzle-orm";
import { db } from "@/db";
import { roadmapTasks } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id: rawId } = await params;
  const id = Number.parseInt(rawId, 10);
  if (!Number.isFinite(id)) {
    return Response.json({ error: "Invalid task id." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const done = Boolean((body as { done?: unknown })?.done);

  try {
    const [updated] = await db
      .update(roadmapTasks)
      .set({ done })
      .where(eq(roadmapTasks.id, id))
      .returning({ id: roadmapTasks.id, done: roadmapTasks.done });
    if (!updated) return Response.json({ error: "Task not found." }, { status: 404 });
    return Response.json(updated);
  } catch (error) {
    console.error("toggle task failed", error);
    return Response.json({ error: "Could not update task." }, { status: 500 });
  }
}
