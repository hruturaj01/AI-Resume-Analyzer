import { listAnalyses } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const limitParam = Number(url.searchParams.get("limit") ?? 20);
  const limit = Number.isFinite(limitParam) ? Math.max(1, Math.min(50, Math.round(limitParam))) : 20;
  try {
    const items = await listAnalyses(limit);
    return Response.json({ items });
  } catch (error) {
    console.error("list analyses failed", error);
    return Response.json({ error: "Could not load analyses." }, { status: 500 });
  }
}
