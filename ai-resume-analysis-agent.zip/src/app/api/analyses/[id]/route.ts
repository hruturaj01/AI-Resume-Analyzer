import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses } from "@/db/schema";
import { getAnalysis } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const result = await getAnalysis(id);
    if (!result) return Response.json({ error: "Analysis not found." }, { status: 404 });
    return Response.json({
      analysis: {
        publicId: result.analysis.publicId,
        createdAt: result.analysis.createdAt,
        resumeText: result.analysis.resumeText,
        report: result.analysis.report,
      },
      tasks: result.tasks,
    });
  } catch (error) {
    console.error("get analysis failed", error);
    return Response.json({ error: "Could not load analysis." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const deleted = await db.delete(analyses).where(eq(analyses.publicId, id)).returning({ id: analyses.id });
    if (!deleted.length) return Response.json({ error: "Analysis not found." }, { status: 404 });
    return Response.json({ ok: true });
  } catch (error) {
    console.error("delete analysis failed", error);
    return Response.json({ error: "Could not delete analysis." }, { status: 500 });
  }
}
