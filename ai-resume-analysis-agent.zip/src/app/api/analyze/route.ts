import { randomBytes } from "crypto";
import { db } from "@/db";
import { analyses, roadmapTasks } from "@/db/schema";
import { enrichReport } from "@/lib/agent/enrich";
import { buildTaskRows, runAgent } from "@/lib/agent/engine";
import { LEVELS } from "@/lib/roles";
import type { LevelKey } from "@/lib/types";

export const dynamic = "force-dynamic";

const LEVEL_VALUES = new Set<string>(LEVELS.map((level) => level.value));

function newPublicId(): string {
  return randomBytes(8).toString("hex");
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const payload = (body ?? {}) as {
    resumeText?: unknown;
    targetRole?: unknown;
    level?: unknown;
    weeks?: unknown;
    fileName?: unknown;
  };

  const resumeText = typeof payload.resumeText === "string" ? payload.resumeText.trim() : "";
  if (resumeText.length < 120) {
    return Response.json(
      { error: "Paste at least 120 characters of resume text so the agent has something to analyse." },
      { status: 400 },
    );
  }
  if (resumeText.length > 40000) {
    return Response.json({ error: "Resume is too long. Keep it under 40,000 characters." }, { status: 400 });
  }

  const targetRole = typeof payload.targetRole === "string" && payload.targetRole ? payload.targetRole : "auto";
  const levelInput = typeof payload.level === "string" ? payload.level : "fresher";
  const level: LevelKey = (LEVEL_VALUES.has(levelInput) ? levelInput : "fresher") as LevelKey;
  const weeksRaw = typeof payload.weeks === "number" ? payload.weeks : Number(payload.weeks ?? 12);
  const weeks = Number.isFinite(weeksRaw) ? Math.max(4, Math.min(24, Math.round(weeksRaw))) : 12;
  const fileName = typeof payload.fileName === "string" ? payload.fileName.slice(0, 160) : null;

  try {
    const report = await enrichReport(
      runAgent({ resumeText, targetRole, level, weeks, fileName: fileName ?? undefined }),
      resumeText,
    );
    const publicId = newPublicId();

    const [inserted] = await db
      .insert(analyses)
      .values({
        publicId,
        candidateName: report.candidate.name,
        targetRole: report.candidate.targetRoleSlug,
        targetRoleTitle: report.candidate.targetRoleTitle,
        level: report.candidate.level,
        weeks,
        overallScore: report.scores.overall,
        atsScore: report.scores.ats,
        readiness: report.readiness,
        resumeText,
        fileName,
        report,
      })
      .returning({ id: analyses.id, publicId: analyses.publicId });

    const taskRows = buildTaskRows(report).map((row) => ({
      analysisId: inserted.id,
      phaseIndex: row.phaseIndex,
      taskIndex: row.taskIndex,
      title: row.title,
    }));
    if (taskRows.length) {
      await db.insert(roadmapTasks).values(taskRows);
    }

    return Response.json(
      {
        publicId: inserted.publicId,
        scores: report.scores,
        readiness: report.readiness,
        headline: report.headline,
        targetRoleTitle: report.candidate.targetRoleTitle,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("analyze failed", error);
    return Response.json({ error: "The agent could not complete this analysis. Try again." }, { status: 500 });
  }
}
