import Link from "next/link";
import { AnalyzeForm } from "@/components/analyze-form";
import { RoleCard } from "@/components/role-card";
import { ScoreBar } from "@/components/score-ring";
import { SiteFooter, SiteNav } from "@/components/site-nav";
import { ROLES, getRole, type RoleDef } from "@/lib/roles";
import { listAnalyses } from "@/lib/queries";

export const dynamic = "force-dynamic";

const PIPELINE = [
  {
    step: "01",
    title: "Ingest",
    body: "Normalises your resume text, detects sections, contact links, projects and every technology named.",
  },
  {
    step: "02",
    title: "Audit",
    body: "20 parse-level ATS checks, impact scoring and a quantified-achievement ratio — the signals recruiters screen on.",
  },
  {
    step: "03",
    title: "Match",
    body: "Scores you against 12 placement tracks, ranks salary bands and exposes the exact missing requirements.",
  },
  {
    step: "04",
    title: "Build",
    body: "Sequences a week-by-week roadmap: skills, portfolio projects, interview drills and the application sprint.",
  },
];

const PROOF = [
  { value: "12", label: "role tracks scored" },
  { value: "20+", label: "ATS & impact checks" },
  { value: "4", label: "roadmap phases" },
  { value: "∞", label: "re-runs, tracked progress" },
];

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ role?: string }>;
}) {
  const { role: roleParam } = await searchParams;
  const initialRole = roleParam && getRole(roleParam) ? roleParam : undefined;

  let recent: Awaited<ReturnType<typeof listAnalyses>> = [];
  try {
    recent = await listAnalyses(4);
  } catch {
    recent = [];
  }

  const featured = [
    "full-stack-engineer",
    "frontend-engineer",
    "ai-ml-engineer",
    "data-analyst",
    "devops-engineer",
    "backend-engineer",
  ]
    .map((slug) => getRole(slug))
    .filter((role): role is RoleDef => Boolean(role));

  return (
    <>
      <SiteNav />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="pointer-events-none absolute inset-0 grid-overlay opacity-60" aria-hidden="true" />
          <div className="relative mx-auto grid w-full max-w-6xl gap-10 px-5 pb-16 pt-14 lg:grid-cols-[1.05fr_0.95fr] lg:pt-20">
            <div className="animate-rise">
              <span className="chip chip-accent">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                AI placement agent · resume → roadmap
              </span>
              <h1 className="mt-5 text-[clamp(2.3rem,5.4vw,3.9rem)] font-extrabold leading-[0.98] tracking-[-0.045em] text-white">
                Your resume,
                <br />
                <span className="bg-gradient-to-r from-accent-soft via-accent to-mint bg-clip-text text-transparent">
                  reverse-engineered
                </span>
                <br />
                for the role you want.
              </h1>
              <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-white/60">
                Placemate reads your resume like an hiring panel: it scores ATS parseability, measures the impact of your
                bullets, matches you to real tech placement tracks, and hands you a tracked week-by-week roadmap to
                shortlist.
              </p>

              <ul className="mt-6 space-y-2.5">
                {[
                  "Instant score across ATS, impact, skills, projects, experience and clarity.",
                  "Role fit with matched vs missing requirements and India + global salary bands.",
                  "A deadline-aware plan: skills, portfolio projects, mock interviews and referrals.",
                ].map((line) => (
                  <li key={line} className="flex items-start gap-2.5 text-[13.5px] leading-relaxed text-white/70">
                    <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-accent/15 text-[10px] text-accent">
                      ✓
                    </span>
                    {line}
                  </li>
                ))}
              </ul>

              <div className="mt-7 grid max-w-lg grid-cols-2 gap-2.5 sm:grid-cols-4">
                {PROOF.map((item) => (
                  <div key={item.label} className="card-flat px-3 py-2.5">
                    <p className="text-lg font-bold tracking-tight text-white">{item.value}</p>
                    <p className="mt-0.5 text-[10.5px] leading-tight text-white/40">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>

            <div id="analyzer" className="animate-rise lg:pt-4" style={{ animationDelay: "80ms" }}>
              <AnalyzeForm initialRole={initialRole} />
            </div>
          </div>
        </section>

        {/* Pipeline */}
        <section id="how" className="mx-auto w-full max-w-6xl px-5 py-14">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="label">The agent pipeline</p>
              <h2 className="mt-2 text-[clamp(1.6rem,3vw,2.1rem)] font-extrabold tracking-[-0.035em] text-white">
                Four passes. One honest verdict.
              </h2>
            </div>
            <p className="max-w-sm text-[13px] leading-relaxed text-white/45">
              No black box. Every phase of the analysis is shown in your report, including which checks failed and why.
            </p>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {PIPELINE.map((item) => (
              <div key={item.step} className="card p-5">
                <p className="font-mono text-[11px] tracking-[0.2em] text-accent/70">{item.step}</p>
                <h3 className="mt-3 text-[15px] font-bold text-white">{item.title}</h3>
                <p className="mt-2 text-[12.5px] leading-relaxed text-white/48">{item.body}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Recent runs */}
        {recent.length ? (
          <section className="mx-auto w-full max-w-6xl px-5 pb-4">
            <div className="card overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-5 py-4">
                <div>
                  <p className="label">Recent agent runs</p>
                  <h2 className="mt-1 text-[17px] font-bold tracking-[-0.02em] text-white">Latest resume reports</h2>
                </div>
                <Link href="/dashboard" className="btn-ghost">
                  Open dashboard →
                </Link>
              </div>
              <div className="divide-line">
                {recent.map((row) => (
                  <Link
                    key={row.publicId}
                    href={`/report/${row.publicId}`}
                    className="flex flex-wrap items-center gap-4 px-5 py-3.5 transition hover:bg-white/[0.03]"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13.5px] font-semibold text-white/90">
                        {row.candidateName ?? "Candidate"}{" "}
                        <span className="font-normal text-white/35">· {row.targetRoleTitle}</span>
                      </p>
                      <p className="mt-0.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-white/35">
                        {row.readiness.replace("-", " ")} · {row.weeks}-week plan
                      </p>
                    </div>
                    <div className="w-32">
                      <ScoreBar score={row.overallScore} tone={row.overallScore >= 74 ? "accent" : row.overallScore >= 58 ? "sky" : "rose"} />
                    </div>
                    <span className="w-10 text-right text-[13px] font-bold text-white">{row.overallScore}</span>
                    <span aria-hidden="true" className="text-white/30">→</span>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        ) : null}

        {/* Roles */}
        <section className="mx-auto w-full max-w-6xl px-5 py-14">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="label">Placement tracks</p>
              <h2 className="mt-2 text-[clamp(1.6rem,3vw,2.1rem)] font-extrabold tracking-[-0.035em] text-white">
                {ROLES.length} tech career tracks, fully mapped.
              </h2>
              <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-white/50">
                Browse the requirements, projects and interview topics for each track before you run your analysis.
              </p>
            </div>
            <Link href="/roles" className="btn-ghost">
              All role tracks →
            </Link>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((role) => (
              <RoleCard key={role.slug} role={role} />
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto w-full max-w-6xl px-5 pb-4">
          <div className="relative overflow-hidden rounded-3xl border border-accent/20 bg-gradient-to-br from-accent/12 via-white/[0.03] to-transparent p-7 sm:p-10">
            <div className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full bg-accent/20 blur-3xl" aria-hidden="true" />
            <p className="label">Placement season is a project</p>
            <h2 className="mt-3 max-w-2xl text-[clamp(1.6rem,3.4vw,2.4rem)] font-extrabold leading-tight tracking-[-0.035em] text-white">
              Stop guessing why your resume gets ignored.
            </h2>
            <p className="mt-3 max-w-xl text-[14px] leading-relaxed text-white/60">
              Run one analysis, get the diagnosis and the plan in under a minute. Then track every task until the offer
              lands.
            </p>
            <div className="mt-6 flex flex-wrap gap-2.5">
              <Link href="/#analyzer" className="btn-primary">
                Analyze my resume
                <span aria-hidden="true">→</span>
              </Link>
              <Link href="/roles" className="btn-ghost">
                Explore role tracks
              </Link>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
