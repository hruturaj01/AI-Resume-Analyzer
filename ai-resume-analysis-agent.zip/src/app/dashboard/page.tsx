import Link from "next/link";
import { SavedReports, type SavedReport } from "@/components/saved-reports";
import { SiteFooter, SiteNav } from "@/components/site-nav";
import { analysisStats, listAnalyses } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "My placement reports — Placemate",
  description: "Every resume analysis you have run, with scores and saved roadmap progress.",
};

export default async function DashboardPage() {
  let rows: Awaited<ReturnType<typeof listAnalyses>> = [];
  let loadError = false;
  try {
    rows = await listAnalyses(50);
  } catch {
    loadError = true;
  }

  const formatter = new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  });

  const items: SavedReport[] = rows.map((row) => ({
    publicId: row.publicId,
    candidateName: row.candidateName,
    targetRoleTitle: row.targetRoleTitle,
    level: row.level,
    weeks: row.weeks,
    overallScore: row.overallScore,
    atsScore: row.atsScore,
    readiness: row.readiness,
    createdLabel: formatter.format(new Date(row.createdAt)),
  }));

  const stats = analysisStats(rows);

  return (
    <>
      <SiteNav />
      <main className="mx-auto w-full max-w-6xl px-5 py-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="label">Workspace</p>
            <h1 className="mt-2 text-[clamp(1.9rem,4vw,2.8rem)] font-extrabold leading-tight tracking-[-0.045em] text-white">
              My placement reports
            </h1>
            <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-white/50">
              Every agent run is stored with its roadmap progress. Open a report to tick tasks, or delete runs you no
              longer need.
            </p>
          </div>
          <Link href="/#analyzer" className="btn-primary">
            New analysis →
          </Link>
        </div>

        <div className="mt-7">
          {loadError ? (
            <div className="card p-6">
              <p className="text-[13.5px] text-rose">Could not reach the reports database right now.</p>
              <p className="mt-1 text-[12px] text-white/45">Refresh in a moment, or run a new analysis from the home page.</p>
            </div>
          ) : (
            <SavedReports items={items} stats={stats} />
          )}
        </div>

        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          <Link
            href="/roles"
            className="card group flex items-center justify-between gap-4 p-5 transition hover:border-white/20"
          >
            <div>
              <p className="label">Next step</p>
              <p className="mt-1 text-[14px] font-semibold text-white">Browse all 12 placement tracks</p>
              <p className="mt-1 text-[12px] text-white/45">Compare requirements, projects and salary bands.</p>
            </div>
            <span aria-hidden="true" className="text-accent transition group-hover:translate-x-1">→</span>
          </Link>
          <Link
            href="/?role=ai-ml-engineer#analyzer"
            className="card group flex items-center justify-between gap-4 p-5 transition hover:border-white/20"
          >
            <div>
              <p className="label">Trending track</p>
              <p className="mt-1 text-[14px] font-semibold text-white">AI / ML engineering</p>
              <p className="mt-1 text-[12px] text-white/45">Run your resume against the fastest-growing track.</p>
            </div>
            <span aria-hidden="true" className="text-accent transition group-hover:translate-x-1">→</span>
          </Link>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
