export type SkillCategory =
  | "Languages"
  | "Frontend"
  | "Backend"
  | "Data & AI"
  | "Cloud & DevOps"
  | "Mobile"
  | "Testing & Tools"
  | "Core CS"
  | "Security"
  | "Product";

export type LevelKey = "student" | "fresher" | "mid" | "senior";

export type ReadinessTier = "interview-ready" | "near-ready" | "developing" | "foundation";

export interface DetectedSkill {
  name: string;
  category: SkillCategory;
}

export interface SkillGap {
  skill: string;
  priority: "critical" | "high" | "medium";
  why: string;
}

export interface ResourceLink {
  label: string;
  url: string;
}

export interface ScoreBreakdown {
  overall: number;
  ats: number;
  impact: number;
  skills: number;
  projects: number;
  experience: number;
  clarity: number;
}

export interface RoleMatch {
  slug: string;
  title: string;
  match: number;
  tier: ReadinessTier;
  matchedSkills: string[];
  missingSkills: string[];
  why: string;
  salaryIndia: string;
  demand: string;
}

export interface RoadmapTask {
  key: string;
  title: string;
  detail: string;
  resources: ResourceLink[];
}

export interface RoadmapPhase {
  index: number;
  title: string;
  timeframe: string;
  focus: string;
  outcome: string;
  tasks: RoadmapTask[];
}

export interface ProjectIdea {
  title: string;
  summary: string;
  stack: string[];
  impact: string;
}

export interface GapFinding {
  title: string;
  detail: string;
  severity: "critical" | "high" | "medium";
}

export interface AtsFinding {
  label: string;
  status: "pass" | "warn" | "fail";
  note: string;
}

export interface InterviewTopic {
  topic: string;
  questions: string[];
}

export interface AgentStep {
  name: string;
  detail: string;
  status: "complete";
}

export interface AnalysisReport {
  version: number;
  engine: string;
  agentSteps: AgentStep[];
  candidate: {
    name: string | null;
    email: string | null;
    phone: string | null;
    links: string[];
    years: number;
    level: LevelKey;
    levelLabel: string;
    targetRoleSlug: string;
    targetRoleTitle: string;
    autoPicked: boolean;
  };
  scores: ScoreBreakdown;
  readiness: ReadinessTier;
  readinessLabel: string;
  headline: string;
  summary: string;
  stats: {
    words: number;
    bullets: number;
    quantifiedAchievements: number;
    skillCount: number;
    sectionsFound: number;
  };
  skills: {
    detected: DetectedSkill[];
    byCategory: { category: SkillCategory; skills: string[] }[];
    gaps: SkillGap[];
  };
  strengths: string[];
  gaps: GapFinding[];
  atsFindings: AtsFinding[];
  roleMatches: RoleMatch[];
  roadmap: RoadmapPhase[];
  projects: ProjectIdea[];
  interviewPrep: InterviewTopic[];
  quickWins: string[];
  resources: ResourceLink[];
}

export interface AnalyzeInput {
  resumeText: string;
  targetRole: string;
  level: LevelKey;
  weeks: number;
  fileName?: string;
}
