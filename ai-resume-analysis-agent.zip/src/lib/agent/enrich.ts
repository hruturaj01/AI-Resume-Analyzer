import type { AnalysisReport } from "../types";

/**
 * Optional qualitative pass. The deterministic engine always produces the
 * complete report; when an OpenAI key is available we additionally ask a model
 * to rewrite the narrative sections (verdict, strengths, quick wins) so the
 * report reads like a recruiter wrote it. Any failure falls back silently to
 * the deterministic output.
 */
interface EnrichmentPayload {
  headline?: unknown;
  summary?: unknown;
  strengths?: unknown;
  quickWins?: unknown;
}

function stringList(value: unknown, max: number, minLength = 6): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((entry): entry is string => typeof entry === "string" && entry.trim().length >= minLength)
    .map((entry) => entry.trim())
    .slice(0, max);
}

export async function enrichReport(report: AnalysisReport, resumeText: string): Promise<AnalysisReport> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return report;

  const model = process.env.OPENAI_MODEL ?? "gpt-4o-mini";

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        temperature: 0.3,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content:
              "You are a blunt senior technical recruiter in India who has screened 10,000 engineering resumes. " +
              "Given a resume and a deterministic scoring report, rewrite only the qualitative sections. " +
              "Be specific, concrete and free of filler. Never invent experience that is not in the resume. " +
              'Return strict JSON: { "headline": string (max 160 chars), "summary": string (2-3 sentences), ' +
              '"strengths": string[3], "quickWins": string[3] }.',
          },
          {
            role: "user",
            content: JSON.stringify({
              targetRole: report.candidate.targetRoleTitle,
              level: report.candidate.levelLabel,
              scores: report.scores,
              missingSkills: report.skills.gaps.slice(0, 6).map((gap) => gap.skill),
              detectedSkills: report.skills.detected.map((skill) => skill.name).slice(0, 40),
              resume: resumeText.slice(0, 7000),
            }),
          },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) return report;

    const data = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    const content = data.choices?.[0]?.message?.content;
    if (!content) return report;

    const parsed = JSON.parse(content) as EnrichmentPayload;
    const headline =
      typeof parsed.headline === "string" && parsed.headline.trim().length > 12
        ? parsed.headline.trim().slice(0, 220)
        : report.headline;
    const summary =
      typeof parsed.summary === "string" && parsed.summary.trim().length > 60
        ? parsed.summary.trim()
        : report.summary;
    const strengths = stringList(parsed.strengths, 4, 10);
    const quickWins = stringList(parsed.quickWins, 4, 10);

    return {
      ...report,
      engine: `Placemate Agent v2 · deterministic core + ${model} narration`,
      headline,
      summary,
      strengths: strengths.length ? strengths : report.strengths,
      quickWins: quickWins.length ? quickWins : report.quickWins,
      agentSteps: [
        ...report.agentSteps,
        {
          name: "Recruiter narration",
          detail: `Qualitative rewrite passed through ${model}; scores and roadmap untouched.`,
          status: "complete" as const,
        },
      ],
    };
  } catch {
    return report;
  }
}
