import { levelLabel, ROLES, ROLE_BY_SLUG, type RoleDef } from "../roles";
import { SKILL_CATEGORIES } from "../skills";
import type {
  AnalysisReport,
  AnalyzeInput,
  AtsFinding,
  DetectedSkill,
  GapFinding,
  InterviewTopic,
  LevelKey,
  ProjectIdea,
  ReadinessTier,
  ResourceLink,
  RoadmapPhase,
  RoleMatch,
  ScoreBreakdown,
  SkillCategory,
  SkillGap,
} from "../types";
import { parseResume, type ParsedResume } from "./parse";

const EXPECTED_YEARS: Record<LevelKey, number> = { student: 0, fresher: 1, mid: 3, senior: 5 };

const RESOURCES = {
  roadmapProjects: { label: "Build real projects", url: "https://roadmap.sh/projects" },
  dsa: { label: "Striver A2Z DSA sheet", url: "https://takeuforward.org/strivers-a2z-dsa-course/strivers-a2z-dsa-course-sheet-2/" },
  neetcode: { label: "NeetCode 150", url: "https://neetcode.io/practice" },
  interviewHandbook: { label: "Tech interview handbook", url: "https://www.techinterviewhandbook.org/" },
  systemDesign: { label: "System design primer", url: "https://github.com/donnemartin/system-design-primer" },
  sqlPractice: { label: "SQL practice (DataLemur)", url: "https://datalemur.com/questions" },
  mockInterview: { label: "Pramp peer mocks", url: "https://www.pramp.com/" },
  starStories: { label: "STAR method guide", url: "https://www.themuse.com/advice/star-interview-method" },
  githubProfile: { label: "GitHub profile README guide", url: "https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-github-profile" },
  linkedin: { label: "LinkedIn profile checklist", url: "https://www.linkedin.com/help/linkedin/answer/a554351" },
  metrics: { label: "Resume bullet formula (XYZ)", url: "https://www.techinterviewhandbook.org/resume/" },
  referrals: { label: "Warm outreach templates", url: "https://www.techinterviewhandbook.org/negotiation/" },
  salary: { label: "Salary negotiation guide", url: "https://www.levels.fyi/" },
} satisfies Record<string, ResourceLink>;

const DOC_RESOURCES: Record<string, ResourceLink> = {
  React: { label: "React docs — learn", url: "https://react.dev/learn" },
  JavaScript: { label: "JavaScript.info", url: "https://javascript.info/" },
  TypeScript: { label: "TypeScript handbook", url: "https://www.typescriptlang.org/docs/handbook/intro.html" },
  "Next.js": { label: "Next.js learn course", url: "https://nextjs.org/learn" },
  "Node.js": { label: "Node.js guides", url: "https://nodejs.org/en/learn" },
  Python: { label: "Python tutorial", url: "https://docs.python.org/3/tutorial/" },
  SQL: { label: "SQLBolt interactive SQL", url: "https://sqlbolt.com/" },
  PostgreSQL: { label: "PostgreSQL tutorial", url: "https://www.postgresql.org/docs/current/tutorial.html" },
  Docker: { label: "Docker getting started", url: "https://docs.docker.com/get-started/" },
  Kubernetes: { label: "Kubernetes tutorials", url: "https://kubernetes.io/docs/tutorials/" },
  AWS: { label: "AWS skill builder", url: "https://skillbuilder.aws/" },
  Terraform: { label: "Terraform tutorials", url: "https://developer.hashicorp.com/terraform/tutorials" },
  Linux: { label: "Linux journey", url: "https://linuxjourney.com/" },
  "Machine Learning": { label: "Google ML crash course", url: "https://developers.google.com/machine-learning/crash-course" },
  "Deep Learning": { label: "DeepLearning.AI specialisation", url: "https://www.coursera.org/specializations/deep-learning" },
  PyTorch: { label: "PyTorch tutorials", url: "https://pytorch.org/tutorials/" },
  LLMs: { label: "Hugging Face LLM course", url: "https://huggingface.co/learn/llm-course/chapter1/1" },
  RAG: { label: "RAG from scratch (LangChain)", url: "https://github.com/langchain-ai/rag-from-scratch" },
  Pandas: { label: "Pandas 10 minutes", url: "https://pandas.pydata.org/docs/user_guide/10min.html" },
  Statistics: { label: "StatQuest statistics", url: "https://statquest.org/" },
  Playwright: { label: "Playwright docs", url: "https://playwright.dev/docs/intro" },
  Selenium: { label: "Selenium docs", url: "https://www.selenium.dev/documentation/" },
  OWASP: { label: "OWASP Top 10", url: "https://owasp.org/www-project-top-ten/" },
  "Network Security": { label: "TryHackMe network security", url: "https://tryhackme.com/module/network-security" },
  "Product Analytics": { label: "Amplitude product analytics playbook", url: "https://amplitude.com/blog/product-analytics" },
  "React Native": { label: "React Native docs", url: "https://reactnative.dev/docs/getting-started" },
  "Data Visualization": { label: "Data-to-Viz guide", url: "https://www.data-to-viz.com/" },
  "Power BI": { label: "Power BI learning path", url: "https://learn.microsoft.com/en-us/training/powerplatform/power-bi" },
  "System Design": { label: "System design primer", url: "https://github.com/donnemartin/system-design-primer" },
};

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, Math.round(value)));
}

function skillResource(skill: string, role: RoleDef): ResourceLink {
  return (
    DOC_RESOURCES[skill] ?? {
      label: `${skill} learning path`,
      url: `https://roadmap.sh/${role.roadmapSlug}`,
    }
  );
}

function roleFit(parsed: ParsedResume, role: RoleDef): { match: number; matched: string[]; missing: string[]; bonus: string[] } {
  const owned = new Set(parsed.detectedNames);
  const matched = role.coreSkills.filter((skill) => owned.has(skill));
  const missing = role.coreSkills.filter((skill) => !owned.has(skill));
  const bonusMatched = role.bonusSkills.filter((skill) => owned.has(skill));
  const bonus = role.bonusSkills.filter((skill) => !owned.has(skill));
  const coreCoverage = matched.length / role.coreSkills.length;
  const bonusCoverage = bonusMatched.length / Math.max(1, role.bonusSkills.length);
  const breadth = Math.min(parsed.detected.length / 18, 1);
  const match = clamp(coreCoverage * 68 + bonusCoverage * 12 + breadth * 20);
  return { match, matched, missing, bonus };
}

function pickRole(parsed: ParsedResume, requested: string): { role: RoleDef; autoPicked: boolean } {
  const explicit = ROLE_BY_SLUG.get(requested);
  if (explicit) return { role: explicit, autoPicked: false };
  const ranked = ROLES.map((role) => ({ role, match: roleFit(parsed, role).match })).sort((a, b) => b.match - a.match);
  return { role: ranked[0].role, autoPicked: true };
}

function buildScores(parsed: ParsedResume, role: RoleDef, fit: ReturnType<typeof roleFit>, level: LevelKey): ScoreBreakdown {
  const findings: [boolean, number][] = [
    [Boolean(parsed.email), 12],
    [Boolean(parsed.phone), 6],
    [parsed.links.length > 0, 8],
    [parsed.sections.summary, 6],
    [parsed.sections.skills, 12],
    [parsed.sections.experience, 12],
    [parsed.sections.projects, 10],
    [parsed.sections.education, 10],
  ];
  let ats = findings.reduce((total, [present, points]) => total + (present ? points : 0), 0);
  ats += parsed.words >= 300 && parsed.words <= 900 ? 14 : parsed.words >= 180 && parsed.words <= 1100 ? 8 : 2;
  ats += parsed.bullets >= 10 ? 8 : parsed.bullets >= 5 ? 4 : 0;
  ats += parsed.detected.length >= 12 ? 10 : parsed.detected.length >= 7 ? 6 : 2;
  ats += parsed.tableLikeLines === 0 ? 10 : 3;

  const quantRatio = Math.min(parsed.quantifiedAchievements / 4, 1);
  const impact = clamp(
    20 +
      quantRatio * 38 +
      Math.min(parsed.actionVerbs.length, 8) * 3 +
      (parsed.bullets >= 10 ? 12 : Math.min(parsed.bullets * 2, 10)) +
      (parsed.sections.projects ? 8 : 0) -
      parsed.buzzwords.length * 2,
    10,
  );

  const coreCoverage = fit.matched.length / role.coreSkills.length;
  const bonusCoverage =
    role.bonusSkills.filter((skill) => parsed.detectedNames.includes(skill)).length / Math.max(1, role.bonusSkills.length);
  const skills = clamp(25 + coreCoverage * 50 + bonusCoverage * 10 + Math.min(parsed.detected.length / 20, 1) * 15, 15);

  const projects = clamp(
    (parsed.sections.projects ? 25 : 0) +
      Math.min(parsed.projectCount, 4) * 14 +
      (parsed.links.some((link) => /github|gitlab/i.test(link)) ? 12 : 0) +
      (parsed.quantifiedAchievements >= 3 ? 9 : 0) +
      8,
    10,
  );

  const expected = EXPECTED_YEARS[level];
  const internships = /intern(ship)?/i.test(parsed.text);
  const certifications = parsed.sections.certifications || /certif/i.test(parsed.text);
  const experience = clamp(
    expected === 0
      ? 50 + (parsed.projectCount >= 2 ? 20 : parsed.projectCount * 8) + (internships ? 20 : 0)
      : 35 + Math.min(parsed.years / expected, 1) * 45 + (internships ? 10 : 0) + (certifications ? 10 : 0),
    15,
  );

  const clarity = clamp(
    40 +
      (parsed.bullets >= 8 ? 18 : parsed.bullets * 2) +
      (parsed.words >= 250 && parsed.words <= 900 ? 18 : parsed.words < 250 ? 4 : 10) +
      (parsed.actionVerbs.length >= 5 ? 10 : 5) +
      (parsed.sections.summary ? 8 : 0) -
      parsed.longParagraphs * 5 -
      parsed.buzzwords.length * 2 -
      (parsed.tableLikeLines > 0 ? 8 : 0),
    20,
  );

  const overall = clamp(
    ats * 0.22 + impact * 0.22 + skills * 0.24 + projects * 0.14 + experience * 0.1 + clarity * 0.08,
  );

  return { overall, ats: clamp(ats, 20), impact, skills, projects, experience, clarity };
}

function readinessFrom(overall: number, topMatch: number): ReadinessTier {
  const signal = overall * 0.6 + topMatch * 0.4;
  if (signal >= 76 && overall >= 74) return "interview-ready";
  if (signal >= 62) return "near-ready";
  if (signal >= 47) return "developing";
  return "foundation";
}

const READINESS_LABEL: Record<ReadinessTier, string> = {
  "interview-ready": "Interview ready",
  "near-ready": "Near ready",
  developing: "Developing",
  foundation: "Foundation stage",
};

function buildSkillGaps(parsed: ParsedResume, role: RoleDef, fit: ReturnType<typeof roleFit>): SkillGap[] {
  const gaps: SkillGap[] = [];
  fit.missing.slice(0, 6).forEach((skill, index) => {
    gaps.push({
      skill,
      priority: index < 3 ? "critical" : "high",
      why: `${role.title} job descriptions list ${skill} as a core requirement and it is missing from your resume.`,
    });
  });
  role.bonusSkills
    .filter((skill) => !parsed.detectedNames.includes(skill))
    .slice(0, 3)
    .forEach((skill) => {
      gaps.push({
        skill,
        priority: "medium",
        why: `Differentiator skill for ${role.title} roles — present in strong competing resumes.`,
      });
    });
  if (!parsed.detectedNames.includes("Git")) {
    gaps.push({ skill: "Git", priority: "critical", why: "Every engineering panel assumes working Git/PR workflow." });
  }
  return gaps.slice(0, 9);
}

function buildAtsFindings(parsed: ParsedResume): AtsFinding[] {
  const sectionCount = Object.values(parsed.sections).filter(Boolean).length;
  return [
    {
      label: "Professional email detected",
      status: parsed.email ? "pass" : "fail",
      note: parsed.email ? parsed.email : "Add a clean email in the header — parsers reject resumes without one.",
    },
    {
      label: "Phone number detected",
      status: parsed.phone ? "pass" : "warn",
      note: parsed.phone ? parsed.phone : "Add a phone number with country code.",
    },
    {
      label: "Portfolio / GitHub / LinkedIn link",
      status: parsed.links.length > 0 ? "pass" : "fail",
      note: parsed.links.length > 0 ? `${parsed.links.length} link(s) found` : "Recruiters need one clickable proof link.",
    },
    {
      label: "Standard section headings",
      status: sectionCount >= 4 ? "pass" : sectionCount >= 2 ? "warn" : "fail",
      note: `${sectionCount} of 7 standard sections found (Summary, Skills, Experience, Projects, Education, Certifications, Achievements).`,
    },
    {
      label: "Dedicated skills section",
      status: parsed.sections.skills ? "pass" : "fail",
      note: parsed.sections.skills
        ? `${parsed.detected.length} skills recognised by the parser`
        : "Add a 'Skills' block so keyword matching can actually fire.",
    },
    {
      label: "Experience or internships",
      status: parsed.sections.experience ? "pass" : "warn",
      note: parsed.sections.experience
        ? "Experience section parsed"
        : "No experience heading found — list internships, freelance or open-source work.",
    },
    {
      label: "Quantified achievements",
      status: parsed.quantifiedAchievements >= 4 ? "pass" : parsed.quantifiedAchievements >= 1 ? "warn" : "fail",
      note: `${parsed.quantifiedAchievements} bullet(s) contain measurable outcomes. Aim for at least 60% of bullets.`,
    },
    {
      label: "Resume length",
      status: parsed.words >= 250 && parsed.words <= 900 ? "pass" : "warn",
      note: `${parsed.words} words. Fresher resumes should land between 300–700 words (one page).`,
    },
    {
      label: "Bullet-point formatting",
      status: parsed.bullets >= 8 ? "pass" : parsed.bullets >= 3 ? "warn" : "fail",
      note: `${parsed.bullets} bullet(s) detected. Paragraph blocks are hard for both ATS and skim-reading humans.`,
    },
    {
      label: "ATS-safe layout",
      status: parsed.tableLikeLines === 0 ? "pass" : "fail",
      note:
        parsed.tableLikeLines === 0
          ? "No table-like structures detected in the text layer."
          : `${parsed.tableLikeLines} table-like row(s) found — replace columns with single-column bullets.`,
    },
  ];
}

function buildStrengths(parsed: ParsedResume, role: RoleDef, fit: ReturnType<typeof roleFit>, scores: ScoreBreakdown): string[] {
  const strengths: string[] = [];
  if (fit.matched.length >= 4) {
    strengths.push(`Matches ${fit.matched.length}/${role.coreSkills.length} core ${role.title} skills, including ${fit.matched.slice(0, 4).join(", ")}.`);
  } else if (fit.matched.length > 0) {
    strengths.push(`Working base in ${fit.matched.join(", ")} — a viable starting point for ${role.title}.`);
  }
  if (parsed.quantifiedAchievements >= 4) {
    strengths.push(`Results-oriented writing: ${parsed.quantifiedAchievements} quantified bullets give interviewers something to probe.`);
  }
  if (parsed.projectCount >= 2) {
    strengths.push(`${parsed.projectCount} project signals detected — enough raw material to build a portfolio narrative.`);
  }
  if (parsed.links.length > 0) {
    strengths.push(`Verifiable links present (${parsed.links.length}) so a recruiter can validate your claims in one click.`);
  }
  if (parsed.actionVerbs.length >= 6) {
    strengths.push(`Strong action vocabulary (${parsed.actionVerbs.slice(0, 5).join(", ")}) — bullets read like ownership, not duties.`);
  }
  if (parsed.detected.length >= 14) {
    strengths.push(`Broad technical surface area: ${parsed.detected.length} distinct technologies recognised.`);
  }
  if (scores.clarity >= 75) {
    strengths.push("Clean, scannable structure — the document is easy for a 30-second skim.");
  }
  return strengths.slice(0, 6);
}

function buildGaps(parsed: ParsedResume, role: RoleDef, fit: ReturnType<typeof roleFit>, scores: ScoreBreakdown): GapFinding[] {
  const gaps: GapFinding[] = [];
  if (fit.missing.length > 0) {
    gaps.push({
      title: `${fit.missing.length} core ${role.title} skill(s) missing`,
      detail: `No evidence of ${fit.missing.join(", ")}. These are the keywords screening tools and panels look for first.`,
      severity: fit.missing.length >= 4 ? "critical" : "high",
    });
  }
  if (parsed.quantifiedAchievements < 3) {
    gaps.push({
      title: "Achievements are not measurable",
      detail: "Most bullets describe activity, not outcome. Rewrite using the XYZ formula: accomplished X, measured by Y, by doing Z.",
      severity: "critical",
    });
  }
  if (!parsed.sections.projects || parsed.projectCount < 2) {
    gaps.push({
      title: "Thin proof-of-work portfolio",
      detail: "Two deployed projects with live links and READMEs are the minimum bar for product-company shortlists.",
      severity: "high",
    });
  }
  if (parsed.links.length === 0) {
    gaps.push({
      title: "No verifiable links",
      detail: "Add GitHub, LinkedIn and one live project URL to the header. Unverifiable claims get discounted.",
      severity: "high",
    });
  }
  if (!parsed.sections.summary) {
    gaps.push({
      title: "No positioning summary",
      detail: `Open with 2 lines: who you are, the ${role.title} track you are targeting, and your strongest proof point.`,
      severity: "medium",
    });
  }
  if (scores.ats < 70) {
    gaps.push({
      title: "ATS parse risk",
      detail: "Fix the failing checks in the ATS audit before applying — a human never sees a rejected parse.",
      severity: "high",
    });
  }
  if (parsed.words < 200) {
    gaps.push({ title: "Resume is too thin", detail: "Add projects with stack + outcome, and internship or open-source detail.", severity: "medium" });
  }
  if (parsed.words > 1000) {
    gaps.push({ title: "Resume is too long", detail: "Cut to one page for under 5 years of experience; keep only the strongest 40% of bullets.", severity: "medium" });
  }
  return gaps.slice(0, 6);
}

function timeframe(start: number, end: number): string {
  return start === end ? `Week ${start}` : `Weeks ${start}–${end}`;
}

function buildRoadmap(
  parsed: ParsedResume,
  role: RoleDef,
  fit: ReturnType<typeof roleFit>,
  gaps: SkillGap[],
  level: LevelKey,
  weeks: number,
): RoadmapPhase[] {
  const safeWeeks = Math.max(4, weeks);
  const p1 = Math.max(1, Math.round(safeWeeks * 0.2));
  const p2 = Math.max(1, Math.round(safeWeeks * 0.3));
  const p3 = Math.max(1, Math.round(safeWeeks * 0.3));
  const p4 = Math.max(1, safeWeeks - p1 - p2 - p3);

  const critical = gaps.filter((gap) => gap.priority !== "medium").map((gap) => gap.skill);
  const learnTargets = critical.slice(0, 3);
  const secondaryTargets = critical.slice(3, 5);
  const bonusTargets = gaps.filter((gap) => gap.priority === "medium").map((gap) => gap.skill).slice(0, 2);

  const key = (phase: number, task: number) => `p${phase}-t${task}`;
  const phases: Omit<RoadmapPhase, "index">[] = [];

  // Phase 1 — foundations
  const p1Tasks = learnTargets.map((skill, index) => ({
    key: key(1, index + 1),
    title: `Build a working ${skill} foundation`,
    detail: `Spend 4–6 focused sessions on ${skill}: follow the core guide, then write a small demo that proves you can use it without a tutorial. Add "${skill}" to your skills block only after that demo exists.`,
    resources: [skillResource(skill, role)],
  }));
  p1Tasks.push({
    key: key(1, p1Tasks.length + 1),
    title: "Rewrite your resume with XYZ impact bullets",
    detail:
      "Convert every duty bullet into: action verb + what you built + measurable outcome. Force a metric into at least 60% of bullets — %, latency, users, time saved, cost, rank.",
    resources: [RESOURCES.metrics],
  });
  p1Tasks.push({
    key: key(1, p1Tasks.length + 1),
    title: "Stand up your proof-of-work profile",
    detail:
      "Pin 3 repos, add a profile README with your stack and current focus, deploy one project link, and align your LinkedIn headline to the target role.",
    resources: [RESOURCES.githubProfile, RESOURCES.linkedin],
  });
  p1Tasks.push({
    key: key(1, p1Tasks.length + 1),
    title: `${role.title} role decomposition`,
    detail: `Collect 15 live ${role.title} job descriptions, tag the recurring requirements, and map each one to evidence you have (or a task in this roadmap). This becomes your application checklist.`,
    resources: [{ label: "Role knowledge map", url: `https://roadmap.sh/${role.roadmapSlug}` }],
  });
  phases.push({
    title: "Diagnose & stabilize the fundamentals",
    timeframe: timeframe(1, p1),
    focus: "Remove the keyword and fundamentals blockers that cause instant rejection.",
    outcome: `Resume passes ATS and you can speak credibly about ${learnTargets.join(", ") || role.coreSkills.slice(0, 3).join(", ")}.`,
    tasks: p1Tasks.slice(0, 5),
  });

  // Phase 2 — proof of work
  const p2Start = p1 + 1;
  const p2End = p1 + p2;
  const p2Tasks = role.projects.slice(0, 2).map((project, index) => ({
    key: key(2, index + 1),
    title: `Ship: ${project.title}`,
    detail: `${project.summary} Stack: ${project.stack.join(", ")}. Why it converts: ${project.impact}`,
    resources: [RESOURCES.roadmapProjects, ...(project.stack[0] ? [skillResource(project.stack[0], role)] : [])],
  }));
  if (secondaryTargets.length) {
    p2Tasks.push({
      key: key(2, p2Tasks.length + 1),
      title: `Add ${secondaryTargets[0]} as a differentiator`,
      detail: `Integrate ${secondaryTargets.join(" and ")} into the project you just shipped, then add a README section explaining the trade-off you made.`,
      resources: [skillResource(secondaryTargets[0], role)],
    });
  }
  p2Tasks.push({
    key: key(2, p2Tasks.length + 1),
    title: "Publish, document, demo",
    detail:
      "Deploy publicly, write a README with problem → architecture → decisions → results, record a 90-second demo, and add the live link to your resume header.",
    resources: [RESOURCES.roadmapProjects],
  });
  phases.push({
    title: "Build verifiable proof of work",
    timeframe: timeframe(p2Start, p2End),
    focus: `Create two portfolio artifacts that map 1:1 to ${role.title} on-the-job work.`,
    outcome: "A recruiter can click a link and validate your skills within 60 seconds.",
    tasks: p2Tasks.slice(0, 4),
  });

  // Phase 3 — interview conditioning
  const p3Start = p2End + 1;
  const p3End = p2End + p3;
  const p3Tasks = role.interviewTopics.slice(0, 3).map((topic, index) => ({
    key: key(3, index + 1),
    title: `Drill: ${topic}`,
    detail: `Work through 15 ${topic.toLowerCase()} questions out loud. Record answers, cut filler, and build a one-page cheat sheet of the 8 facts you keep forgetting.`,
    resources: [RESOURCES.interviewHandbook],
  }));
  const isData = role.category === "Data & AI";
  p3Tasks.push({
    key: key(3, p3Tasks.length + 1),
    title: isData ? "SQL + statistics reps under time pressure" : "Timed problem-solving reps",
    detail: isData
      ? "Complete 30 timed SQL questions (joins, window functions, funnels) and 10 statistics drills on experiment design."
      : "Solve 3 problems per day from a curated list. Focus on pattern recognition and verbalizing your approach before coding.",
    resources: isData ? [RESOURCES.sqlPractice] : [RESOURCES.dsa, RESOURCES.neetcode],
  });
  p3Tasks.push({
    key: key(3, p3Tasks.length + 1),
    title: "Two recorded mock interviews",
    detail: `Run one ${role.title}-style technical mock and one behavioural mock. Score yourself on structure, clarity and depth; fix the weakest dimension before the next mock.`,
    resources: [RESOURCES.mockInterview, RESOURCES.starStories],
  });
  if (!isData && (role.category === "Engineering" || role.category === "Cloud & Security")) {
    p3Tasks.push({
      key: key(3, p3Tasks.length + 1),
      title: "System design story deck",
      detail: `Prepare 3 designs relevant to ${role.title}: a URL shortener with analytics, a notification fan-out service, and one system from your own projects. Cover scale assumptions, data model, caching, failure modes.`,
      resources: [RESOURCES.systemDesign],
    });
  }
  phases.push({
    title: "Interview conditioning",
    timeframe: timeframe(p3Start, p3End),
    focus: "Convert knowledge into interview performance under time pressure.",
    outcome: "You can answer core questions in structured, quantified answers without freezing.",
    tasks: p3Tasks.slice(0, 5),
  });

  // Phase 4 — placement sprint
  const p4Start = p3End + 1;
  const p4End = p3End + p4;
  const applications = level === "student" || level === "fresher" ? 20 : 12;
  phases.push({
    title: "Placement sprint",
    timeframe: timeframe(p4Start, p4End),
    focus: "Turn preparation into interviews and offers with a measurable weekly cadence.",
    outcome: "A live pipeline of interviews and at least one competitive offer.",
    tasks: [
      {
        key: key(4, 1),
        title: "Build the target-company list",
        detail: `Shortlist 40 companies hiring ${role.title} (${role.salaryIndia} band): 15 stretch, 15 fit, 10 safety. Record referral contact, careers link and application deadline for each.`,
        resources: [{ label: "Role market map", url: `https://roadmap.sh/${role.roadmapSlug}` }],
      },
      {
        key: key(4, 2),
        title: "Referrals before applications",
        detail: "Send 10 warm messages per week to alumni and engineers: 3 lines of context, one proof link, one specific ask. Referrals convert 5–10× better than cold portal applications.",
        resources: [RESOURCES.referrals, RESOURCES.linkedin],
      },
      {
        key: key(4, 3),
        title: `Apply to ${applications} tailored roles weekly`,
        detail: "Tailor the skills block and top 3 bullets per role. Track every application in a sheet with date, source, stage and follow-up. Never send the same resume twice.",
        resources: [RESOURCES.interviewHandbook],
      },
      {
        key: key(4, 4),
        title: "Offer, compare, negotiate",
        detail: "Score offers on learning, team, compensation and stability. Use one competing offer (or market data) to negotiate base by 10–20%, and get every promise in writing.",
        resources: [RESOURCES.salary],
      },
    ],
  });

  return phases.map((phase, index) => ({ index: index + 1, ...phase }));
}

const QUESTION_OVERRIDES: Record<string, string[]> = {
  "JavaScript fundamentals": ["Explain the event loop with a concrete async example.", "What breaks with `this` in callbacks, and how do you fix it?", "Difference between `==`, `===` and Object.is — with gotchas."],
  "React + component design": ["How do you decide between local state, context and a query cache?", "Walk me through a component you refactored for reusability.", "Debug an infinite re-render caused by an effect."],
  "API & schema design": ["Design the schema and endpoints for a booking system.", "How do you version a public API without breaking clients?", "Where do you enforce business invariants — app or database?"],
  "Advanced SQL": ["Write a query for 7-day retention by signup cohort.", "Explain window functions with a ranking use case.", "How would you debug a slow join in production?"],
  "RAG architecture": ["Design retrieval for 1M documents with citations.", "How do you measure whether your RAG answers are grounded?", "Chunking strategy trade-offs and how you'd test them."],
  "System Design": ["Design a rate limiter for a multi-tenant API.", "How do you keep two services consistent without 2PC?", "Walk through your caching layers and invalidation strategy."],
  "Core AWS services": ["Choose compute for a spiky web workload and justify it.", "How do you design least-privilege access for a CI role?", "Explain VPC subnets and how traffic reaches a private service."],
  "OWASP Top 10": ["Walk through an injection finding and its fix.", "How do you test for broken access control?", "Where does security fit into your SDLC?"],
  "Product sense": ["Pick a product you use daily and improve retention in 30 days.", "Define the north-star metric for a two-sided marketplace.", "How would you decide whether to build, buy or partner?"],
  "Test strategy": ["How do you decide the test pyramid for a new service?", "What do you automate first when release time is halved?", "How do you distinguish test flakiness from a real bug?"],
  "App architecture": ["How do you structure navigation and data layers for scale?", "Offline-first: how do you resolve sync conflicts?", "What is your mobile performance budget?"],
  "Metrics & experiment design": ["Design an experiment to test a checkout change.", "How do you detect a metric that is moving for the wrong reason?", "Explain statistical power to a skeptical PM."],
};

function buildInterviewPrep(role: RoleDef): InterviewTopic[] {
  return role.interviewTopics.slice(0, 4).map((topic) => ({
    topic,
    questions:
      QUESTION_OVERRIDES[topic] ??
      [
        `Walk me through a project where ${topic.toLowerCase()} was the deciding factor.`,
        `What are the biggest trade-offs you have made in ${topic.toLowerCase()}?`,
        `Something breaks in production related to ${topic.toLowerCase()} — how do you debug it end to end?`,
      ],
  }));
}

function buildQuickWins(parsed: ParsedResume, gaps: SkillGap[], scores: ScoreBreakdown): string[] {
  const wins: string[] = [];
  if (!parsed.email || parsed.links.length === 0) wins.push("Add email + GitHub + LinkedIn in the first two lines (5-minute fix, immediate ATS gain).");
  if (parsed.quantifiedAchievements < 4) wins.push("Add a number to your top 3 bullets — %, users, latency, time saved or score.");
  if (gaps[0]) wins.push(`Start with ${gaps[0].skill}: it is the highest-leverage missing skill for your target role.`);
  if (!parsed.sections.skills) wins.push("Create a 'Skills' section grouped by category so keyword parsers can match you.");
  if (parsed.buzzwords.length) wins.push(`Delete soft filler (${parsed.buzzwords.slice(0, 3).join(", ")}) and replace it with evidence.`);
  if (scores.impact < 60) wins.push("Lead each project bullet with the outcome, not the tool list.");
  if (parsed.links.length && !parsed.links.some((link) => /github/i.test(link))) wins.push("Pin your best repo and add a 3-line README summary at the top.");
  return wins.slice(0, 6);
}

function buildResourceList(role: RoleDef): ResourceLink[] {
  return [
    { label: `${role.title} roadmap`, url: `https://roadmap.sh/${role.roadmapSlug}` },
    RESOURCES.interviewHandbook,
    RESOURCES.dsa,
    RESOURCES.sqlPractice,
    RESOURCES.roadmapProjects,
    RESOURCES.mockInterview,
  ];
}

function headlineFor(
  overall: number,
  role: RoleDef,
  gaps: SkillGap[],
  weeks: number,
  readiness: ReadinessTier,
): string {
  if (readiness === "interview-ready") {
    return `Interview-ready for ${role.title} roles. Protect the score and start applying this week.`;
  }
  if (readiness === "near-ready") {
    return `Strong ${role.title} foundation — closing ${gaps[0]?.skill ?? "the last few gaps"} moves you into the shortlist band.`;
  }
  if (readiness === "developing" || overall >= 45) {
    return `Promising profile with fixable gaps. The next ${weeks} weeks decide your ${role.title} placement band.`;
  }
  return `Early-stage profile. The next ${weeks} weeks of focused execution matter more than everything behind you.`;
}

function summaryFor(parsed: ParsedResume, role: RoleDef, scores: ScoreBreakdown, fit: ReturnType<typeof roleFit>, level: LevelKey, weeks: number): string {
  const parts: string[] = [];
  parts.push(
    `The agent parsed ${parsed.words} words, recognised ${parsed.detected.length} technologies and scored your resume ${scores.overall}/100 against the ${role.title} bar for ${levelLabel(level).toLowerCase()}.`,
  );
  parts.push(
    fit.matched.length
      ? `You already cover ${fit.matched.length} of ${role.coreSkills.length} core role skills (${fit.matched.slice(0, 4).join(", ")}).`
      : `No core ${role.title} skills are clearly evidenced yet, so phase 1 focuses on fundamentals.`,
  );
  if (fit.missing.length) {
    parts.push(`${fit.missing.length} core gaps remain — ${fit.missing.slice(0, 3).join(", ")} — and the roadmap sequences them by hiring impact.`);
  }
  parts.push(`Follow the ${weeks}-week plan below in order; each phase ends with an outcome you can verify.`);
  return parts.join(" ");
}

export function runAgent(input: AnalyzeInput): AnalysisReport {
  const parsed = parseResume(input.resumeText);
  const level = input.level;
  const weeks = Math.max(4, Math.min(24, input.weeks || 12));
  const { role, autoPicked } = pickRole(parsed, input.targetRole);

  const fits = ROLES.map((candidate) => ({ role: candidate, fit: roleFit(parsed, candidate) })).sort(
    (a, b) => b.fit.match - a.fit.match,
  );
  const primaryFit = fits.find((entry) => entry.role.slug === role.slug) ?? fits[0];

  const scores = buildScores(parsed, role, primaryFit.fit, level);
  const roleMatches: RoleMatch[] = fits.slice(0, 6).map(({ role: candidate, fit }) => {
    const tier = readinessFrom(scores.overall, fit.match);
    return {
      slug: candidate.slug,
      title: candidate.title,
      match: fit.match,
      tier,
      matchedSkills: fit.matched,
      missingSkills: fit.missing,
      why:
        fit.matched.length > 0
          ? `Evidenced in your resume: ${fit.matched.slice(0, 4).join(", ")}.${fit.missing.length ? ` Biggest gap: ${fit.missing[0]}.` : " No core skill gaps detected."}`
          : `No direct evidence yet — this track is a longer pivot and needs fundamentals first.`,
      salaryIndia: candidate.salaryIndia,
      demand: candidate.demand,
    };
  });
  if (!roleMatches.some((match) => match.slug === role.slug)) {
    roleMatches.unshift({
      slug: role.slug,
      title: role.title,
      match: primaryFit.fit.match,
      tier: readinessFrom(scores.overall, primaryFit.fit.match),
      matchedSkills: primaryFit.fit.matched,
      missingSkills: primaryFit.fit.missing,
      why: "Your selected target track — scored directly against its core requirements.",
      salaryIndia: role.salaryIndia,
      demand: role.demand,
    });
  }

  const gaps = buildSkillGaps(parsed, role, primaryFit.fit);
  const readiness = readinessFrom(scores.overall, primaryFit.fit.match);
  const atsFindings = buildAtsFindings(parsed);
  const strengths = buildStrengths(parsed, role, primaryFit.fit, scores);
  const gapFindings = buildGaps(parsed, role, primaryFit.fit, scores);
  const roadmap = buildRoadmap(parsed, role, primaryFit.fit, gaps, level, weeks);

  const byCategory = SKILL_CATEGORIES.map((category) => ({
    category,
    skills: parsed.detected.filter((skill: DetectedSkill) => skill.category === category).map((skill) => skill.name),
  })).filter((group: { category: SkillCategory; skills: string[] }) => group.skills.length > 0);

  const projects: ProjectIdea[] = role.projects.map((project) => ({
    title: project.title,
    summary: project.summary,
    stack: project.stack,
    impact: project.impact,
  }));

  const agentSteps = [
    {
      name: "Resume ingested",
      detail: `${parsed.words} words, ${parsed.lines.length} lines, ${parsed.bullets} bullets normalised.`,
      status: "complete" as const,
    },
    {
      name: "Entity + skill extraction",
      detail: `${parsed.detected.length} technologies across ${byCategory.length} categories, ${parsed.links.length} links, ${parsed.projectCount} projects.`,
      status: "complete" as const,
    },
    {
      name: "ATS + impact audit",
      detail: `${atsFindings.filter((finding) => finding.status === "pass").length}/${atsFindings.length} checks passing, ${parsed.quantifiedAchievements} quantified bullets.`,
      status: "complete" as const,
    },
    {
      name: "Role fit scoring",
      detail: `Scored against ${ROLES.length} placement tracks. Best fit: ${fits[0].role.title} (${fits[0].fit.match}%).`,
      status: "complete" as const,
    },
    {
      name: "Roadmap synthesis",
      detail: `${weeks}-week plan across ${roadmap.length} phases, ${roadmap.reduce((total, phase) => total + phase.tasks.length, 0)} tracked tasks.`,
      status: "complete" as const,
    },
  ];

  return {
    version: 2,
    engine: "Placemate Agent v2 · deterministic parser + role-graph scorer",
    agentSteps,
    candidate: {
      name: parsed.name,
      email: parsed.email,
      phone: parsed.phone,
      links: parsed.links,
      years: parsed.years,
      level,
      levelLabel: levelLabel(level),
      targetRoleSlug: role.slug,
      targetRoleTitle: role.title,
      autoPicked,
    },
    scores,
    readiness,
    readinessLabel: READINESS_LABEL[readiness],
    headline: headlineFor(scores.overall, role, gaps, weeks, readiness),
    summary: summaryFor(parsed, role, scores, primaryFit.fit, level, weeks),
    stats: {
      words: parsed.words,
      bullets: parsed.bullets,
      quantifiedAchievements: parsed.quantifiedAchievements,
      skillCount: parsed.detected.length,
      sectionsFound: Object.values(parsed.sections).filter(Boolean).length,
    },
    skills: {
      detected: parsed.detected,
      byCategory,
      gaps,
    },
    strengths,
    gaps: gapFindings,
    atsFindings,
    roleMatches,
    roadmap,
    projects,
    interviewPrep: buildInterviewPrep(role),
    quickWins: buildQuickWins(parsed, gaps, scores),
    resources: buildResourceList(role),
  };
}

export function buildTaskRows(report: AnalysisReport): { phaseIndex: number; taskIndex: number; title: string }[] {
  const rows: { phaseIndex: number; taskIndex: number; title: string }[] = [];
  for (const phase of report.roadmap) {
    phase.tasks.forEach((task, taskIndex) => {
      rows.push({ phaseIndex: phase.index, taskIndex, title: task.title });
    });
  }
  return rows;
}

export function getPrimaryRole(report: AnalysisReport): RoleDef {
  return ROLE_BY_SLUG.get(report.candidate.targetRoleSlug) ?? ROLES[0];
}
