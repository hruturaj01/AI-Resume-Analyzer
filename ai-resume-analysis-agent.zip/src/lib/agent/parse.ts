import { SKILLS, type SkillDef } from "../skills";
import type { DetectedSkill } from "../types";

export interface ParsedResume {
  text: string;
  lines: string[];
  words: number;
  email: string | null;
  phone: string | null;
  links: string[];
  name: string | null;
  detected: DetectedSkill[];
  detectedNames: string[];
  sections: {
    summary: boolean;
    skills: boolean;
    experience: boolean;
    projects: boolean;
    education: boolean;
    certifications: boolean;
    achievements: boolean;
  };
  bullets: number;
  longParagraphs: number;
  quantifiedAchievements: number;
  actionVerbs: string[];
  buzzwords: string[];
  years: number;
  projectCount: number;
  tableLikeLines: number;
  firstPerson: number;
}

const SECTION_KEYWORDS: Record<keyof ParsedResume["sections"], string[]> = {
  summary: ["summary", "objective", "profile", "about me", "career objective"],
  skills: ["skills", "technical skills", "technologies", "tech stack", "core competencies"],
  experience: ["experience", "work history", "employment", "internship", "professional experience"],
  projects: ["projects", "personal projects", "academic projects", "key projects"],
  education: ["education", "academic", "qualification", "coursework"],
  certifications: ["certification", "certificate", "licenses", "courses"],
  achievements: ["achievement", "award", "accomplishment", "honors", "accolades"],
};

const ACTION_VERBS = [
  "led", "built", "developed", "designed", "shipped", "launched", "improved", "increased",
  "reduced", "optimized", "optimised", "automated", "migrated", "mentored", "owned",
  "delivered", "scaled", "implemented", "created", "architected", "streamlined", "deployed",
  "integrated", "refactored", "tested", "analyzed", "analysed", "presented", "collaborated",
];

const BUZZWORDS = [
  "passionate", "hardworking", "hard-working", "team player", "go-getter", "dynamic",
  "self-motivated", "detail-oriented", "synergy", "results-driven", "thought leader",
];

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

interface CompiledSkill {
  skill: SkillDef;
  regexes: RegExp[];
}

const COMPILED: CompiledSkill[] = SKILLS.map((skill) => {
  const terms = Array.from(new Set([skill.name, ...(skill.aliases ?? [])].map((term) => term.toLowerCase())));
  const regexes = terms.map(
    (term) => new RegExp(`(^|[^a-z0-9+#])${escapeRegExp(term)}(?![a-z0-9+#])`, "i"),
  );
  return { skill, regexes };
});

export function extractSkills(text: string): DetectedSkill[] {
  const found: DetectedSkill[] = [];
  for (const compiled of COMPILED) {
    if (compiled.regexes.some((regex) => regex.test(text))) {
      found.push({ name: compiled.skill.name, category: compiled.skill.category });
    }
  }
  return found;
}

function isHeading(line: string, keywords: string[]): boolean {
  const trimmed = line.trim().replace(/[:\-–—]+$/, "").toLowerCase();
  if (!trimmed || trimmed.length > 48) return false;
  return keywords.some((keyword) => trimmed === keyword || trimmed.includes(keyword));
}

export function parseResume(rawText: string): ParsedResume {
  const text = rawText.replace(/\r/g, "").trim();
  const lines = text.split("\n");
  const nonEmpty = lines.map((line) => line.trim()).filter(Boolean);
  const lower = text.toLowerCase();

  const emailMatch = text.match(/[\w.+-]+@[\w-]+\.[\w.]{2,}/);
  const phoneCandidate = text.match(/\+?\d[ \t\d().-]{7,16}\d/)?.[0] ?? null;
  const phoneDigits = phoneCandidate ? phoneCandidate.replace(/\D/g, "") : "";
  const phone = phoneCandidate && phoneDigits.length >= 10 && phoneDigits.length <= 13 ? phoneCandidate.trim() : null;

  const linkSet = new Set<string>();
  for (const match of text.matchAll(/https?:\/\/[^\s<>)"']+/g)) {
    linkSet.add(match[0].replace(/[.,;]+$/, ""));
  }
  for (const match of text.matchAll(/(?:^|[\s(])((?:www\.)?(?:github|linkedin|gitlab)\.com\/[\w./-]+)/gi)) {
    linkSet.add(`https://${match[1].replace(/^www\./, "")}`);
  }

  const sections = {
    summary: false,
    skills: false,
    experience: false,
    projects: false,
    education: false,
    certifications: false,
    achievements: false,
  };
  for (const [key, keywords] of Object.entries(SECTION_KEYWORDS) as [
    keyof ParsedResume["sections"],
    string[],
  ][]) {
    sections[key] = lines.some((line) => isHeading(line, keywords));
  }

  const bulletLines = lines.filter((line) => /^\s*(?:[-•*●▪◦]|\d+[.)])\s+/.test(line));
  const bullets = bulletLines.length;

  const quantifiedAchievements = bulletLines.filter(
    (line) =>
      /\d/.test(line) &&
      /(%|₹|\$|€|x\b|\bms\b|million|thousand|users|clients|customers|requests|reduc|increas|improv|faster|latency|revenue|downloads|minute|hour|second|day|week|month|uptime|throughput|saving|saved|cost|conversion)/i.test(
        line,
      ),
  ).length;

  const verbs = ACTION_VERBS.filter((verb) =>
    new RegExp(`(^|[^a-z])${verb}([^a-z]|$)`, "i").test(lower),
  );
  const buzzwords = BUZZWORDS.filter((word) => lower.includes(word));

  // Experience estimate: explicit "N years" first, then date-range inference.
  let years = 0;
  const explicitYears = Array.from(text.matchAll(/(\d{1,2})\s*\+?\s*(?:years|yrs)/gi)).map((match) =>
    Number.parseInt(match[1], 10),
  );
  if (explicitYears.length) {
    years = Math.max(...explicitYears.filter((value) => value > 0 && value < 30));
  }
  if (!years) {
    const yearMatches = Array.from(text.matchAll(/(19|20)\d{2}/g)).map((match) => Number.parseInt(match[0], 10));
    const plausible = yearMatches.filter((value) => value >= 1995 && value <= new Date().getFullYear() + 1);
    if (plausible.length >= 2) {
      const span = Math.max(...plausible) - Math.min(...plausible);
      if (span > 0 && span < 30) years = span;
    }
  }

  let projectCount = 0;
  let inProjects = false;
  for (const line of lines) {
    if (isHeading(line, SECTION_KEYWORDS.projects)) {
      inProjects = true;
      continue;
    }
    if (
      inProjects &&
      (Object.entries(SECTION_KEYWORDS) as [string, string[]][])
        .filter(([key]) => key !== "projects")
        .some(([, keywords]) => isHeading(line, keywords))
    ) {
      inProjects = false;
    }
    if (inProjects && line.trim().length > 12) {
      if (/^\s*(?:[-•*●▪]|\d+[.)]|[A-Z][\w\s.-]{2,40}\|)/.test(line)) projectCount += 1;
    }
  }
  if (!sections.projects) {
    projectCount = (lower.match(/\bproject\b/g) ?? []).length > 0 ? 1 : 0;
  }
  projectCount = Math.max(0, Math.min(projectCount, 15));

  const words = text.split(/\s+/).filter(Boolean).length;
  const longParagraphs = nonEmpty.filter((line) => line.length > 230).length;
  // Only count genuine table rows as parse risks. Contact headers routinely use
  // "email | phone | github" pipes and must not be penalised as tables.
  const tableLikeLines = lines.filter((line) => {
    if ((line.match(/\|/g) ?? []).length < 2) return false;
    if (/@|https?:\/\/|linkedin|github/i.test(line)) return false;
    return true;
  }).length;
  const firstPerson = (text.match(/\bI\b/g) ?? []).length;

  const name = (() => {
    const first = nonEmpty[0] ?? "";
    if (!first || first.length > 42) return null;
    if (/[@|/]|\d/.test(first)) return null;
    if (/resume|curriculum vitae|biodata|portfolio/i.test(first)) return null;
    const words = first.split(/\s+/);
    if (words.length < 1 || words.length > 4) return null;
    if (!/^[A-Za-z][A-Za-z.'\-\s]+$/.test(first)) return null;
    return first
      .split(/\s+/)
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  })();

  const detected = extractSkills(text);

  return {
    text,
    lines,
    words,
    email: emailMatch ? emailMatch[0] : null,
    phone,
    links: Array.from(linkSet).slice(0, 6),
    name,
    detected,
    detectedNames: detected.map((skill) => skill.name),
    sections,
    bullets,
    longParagraphs,
    quantifiedAchievements,
    actionVerbs: verbs,
    buzzwords,
    years,
    projectCount,
    tableLikeLines,
    firstPerson,
  };
}
