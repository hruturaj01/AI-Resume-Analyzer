export interface SampleResume {
  id: string;
  label: string;
  blurb: string;
  role: string;
  text: string;
}

export const SAMPLES: SampleResume[] = [
  {
    id: "frontend",
    label: "Frontend · strong portfolio",
    blurb: "Good projects, weak metrics. Shows what a near-ready profile looks like.",
    role: "frontend-engineer",
    text: `Aarav Mehta
aarav.mehta@gmail.com | +91 98765 43210 | https://github.com/aaravmehta | https://aarav.dev

SUMMARY
Frontend engineer focused on accessible, fast product interfaces built with React and TypeScript.

SKILLS
Languages: JavaScript, TypeScript, HTML, CSS, SQL
Frameworks: React, Next.js, Tailwind CSS, Redux
Tools: Git, GitHub, Vite, Figma, Jest

EXPERIENCE
Frontend Developer Intern — Lumina Labs (Jun 2024 – Dec 2024)
- Built 14 reusable React components used across 3 internal products
- Improved page load by moving heavy charts to dynamic imports
- Worked with designers to implement the new marketing site
- Fixed accessibility issues reported in the audit

PROJECTS
- Kanban Board | React, TypeScript, Node.js, PostgreSQL
  Built a drag-and-drop task board with authentication, roles and activity history.
- DevFinder | Next.js, Tailwind CSS
  GitHub profile search with caching, keyboard navigation and saved favourites.

EDUCATION
B.Tech Computer Science, VIT Vellore (2020 – 2024), CGPA 8.4/10

CERTIFICATIONS
- Meta Front-End Developer Certificate`,
  },
  {
    id: "switcher",
    label: "Data analyst · career switcher",
    blurb: "Non-CS background, transferable analytics work, no metrics. Great fixable gap demo.",
    role: "data-analyst",
    text: `Priya Nair
priya.nair@outlook.com | +91 91234 56780 | linkedin.com/in/priyanair

OBJECTIVE
Passionate and hardworking professional seeking a data analyst role where I can leverage my analytical skills.

EXPERIENCE
Operations Associate — FinServe (2022 – 2025)
- Prepared weekly reports for the operations manager using Excel and vlookup
- Coordinated with the collections team to track pending cases
- Created dashboards in Power BI for the leadership review
- Was responsible for maintaining the master tracker

SKILLS
Excel, Power BI, SQL, Python, Tableau

PROJECTS
- Sales Dashboard | Power BI
  Built a dashboard on a dummy sales dataset with region and product breakdowns.
- Customer Churn Analysis
  Used Python and Pandas to explore a Kaggle churn dataset.

EDUCATION
B.Com, University of Mumbai (2019 – 2022)

ACHIEVEMENTS
- Completed Google Data Analytics Certificate`,
  },
  {
    id: "backend",
    label: "Backend · fresher, no proof",
    blurb: "Right keywords, thin evidence and no links. Shows the foundation-stage path.",
    role: "backend-engineer",
    text: `Rohit Verma
rohitverma99@email.com

CAREER OBJECTIVE
Hardworking team player looking for an opportunity in a reputed organisation to prove my skills.

EDUCATION
B.E. Information Technology, Pune University, 2024, 7.1 CGPA

TECHNICAL SKILLS
Java, Python, Node.js, MongoDB, MySQL, Data Structures, Algorithms, OOP, Git

PROJECTS
- Library Management System
  Console based application with CRUD operations for books and members.
- Hospital Management API
  REST API built with Node.js and Express with CRUD endpoints.
- Chat application
  Socket based chat with rooms.

INTERNSHIP
Web Development Intern — Nexweb Solutions (3 months)
- Learned about API development and worked on bug fixes.

DECLARATIONS
I hereby declare that the above information is true to the best of my knowledge.`,
  },
];
