export interface RoleProject {
  title: string;
  summary: string;
  stack: string[];
  impact: string;
}

export interface RoleDef {
  slug: string;
  title: string;
  category: "Engineering" | "Data & AI" | "Cloud & Security" | "Product";
  tagline: string;
  summary: string;
  coreSkills: string[];
  bonusSkills: string[];
  salaryIndia: string;
  salaryGlobal: string;
  demand: "Very High" | "High" | "Growing";
  roadmapSlug: string;
  interviewTopics: string[];
  projects: RoleProject[];
}

export const ROLES: RoleDef[] = [
  {
    slug: "frontend-engineer",
    title: "Frontend Engineer",
    category: "Engineering",
    tagline: "Ship interfaces people actually enjoy using.",
    summary:
      "Frontend engineers own the browser experience: component architecture, state, performance, and accessibility. Placements reward candidates with 2–3 polished, deployed UI products and a sharp eye for detail.",
    coreSkills: ["React", "JavaScript", "TypeScript", "HTML", "CSS", "Next.js", "Tailwind CSS", "Git"],
    bonusSkills: ["Jest", "Accessibility", "Redux", "Vite", "Figma"],
    salaryIndia: "₹6–18 LPA",
    salaryGlobal: "$80k–$150k",
    demand: "Very High",
    roadmapSlug: "frontend",
    interviewTopics: ["JavaScript fundamentals", "React + component design", "Browser & performance", "UI system design"],
    projects: [
      {
        title: "Production-grade design system",
        summary:
          "Build 12 accessible components with variants, dark mode, keyboard support and visual documentation. Package it and publish to npm.",
        stack: ["React", "TypeScript", "Tailwind CSS", "Storybook"],
        impact: "Proves component architecture, a11y and API design in one artifact.",
      },
      {
        title: "Data-heavy dashboard with real API",
        summary:
          "Full dashboard with auth, pagination, filters, optimistic updates, skeletons and Lighthouse score above 95.",
        stack: ["Next.js", "TypeScript", "PostgreSQL", "Recharts"],
        impact: "Shows performance thinking and end-to-end ownership recruiters can click through.",
      },
    ],
  },
  {
    slug: "backend-engineer",
    title: "Backend Engineer",
    category: "Engineering",
    tagline: "Design APIs and data flows that don't fall over.",
    summary:
      "Backend roles test API design, database modelling, caching, and reliability. Hiring panels look for evidence you can reason about trade-offs, not just write CRUD handlers.",
    coreSkills: ["Node.js", "Python", "PostgreSQL", "REST APIs", "Docker", "Git", "SQL", "Authentication"],
    bonusSkills: ["Redis", "Microservices", "Kafka", "AWS", "System Design"],
    salaryIndia: "₹7–22 LPA",
    salaryGlobal: "$90k–$165k",
    demand: "Very High",
    roadmapSlug: "backend",
    interviewTopics: ["API & schema design", "DBMS and indexing", "Concurrency & caching", "Scalable system design"],
    projects: [
      {
        title: "Multi-tenant SaaS API",
        summary:
          "REST API with role-based access, rate limiting, background jobs, migrations and load-tested endpoints.",
        stack: ["Node.js", "PostgreSQL", "Redis", "Docker"],
        impact: "Demonstrates tenancy, security and operability — the exact senior signal panels probe.",
      },
      {
        title: "Event-driven order service",
        summary:
          "Producer/consumer pipeline with idempotency, retries, dead-letter handling and metrics dashboards.",
        stack: ["Kafka", "Node.js", "PostgreSQL", "Docker"],
        impact: "Shows you can reason about failure modes, not just the happy path.",
      },
    ],
  },
  {
    slug: "full-stack-engineer",
    title: "Full-Stack Engineer",
    category: "Engineering",
    tagline: "Own a feature from schema to shipped pixels.",
    summary:
      "Full-stack is the highest-volume fresher role in product companies. Breadth wins interviews when it is backed by one deep, deployed product you can defend line by line.",
    coreSkills: ["React", "Node.js", "TypeScript", "PostgreSQL", "REST APIs", "Git", "Next.js", "Docker"],
    bonusSkills: ["AWS", "Redis", "CI/CD", "Prisma", "Tailwind CSS"],
    salaryIndia: "₹7–20 LPA",
    salaryGlobal: "$85k–$155k",
    demand: "Very High",
    roadmapSlug: "full-stack",
    interviewTopics: ["End-to-end feature design", "React state & data fetching", "SQL & ORM trade-offs", "Deployment basics"],
    projects: [
      {
        title: "AI-powered SaaS starter",
        summary:
          "Ship a real multi-user app with auth, billing-ready entitlements, background jobs and CI deploys.",
        stack: ["Next.js", "TypeScript", "PostgreSQL", "Drizzle ORM"],
        impact: "One link that proves you can take a product from zero to production alone.",
      },
      {
        title: "Realtime collaboration tool",
        summary:
          "Realtime editing or chat with presence, conflict handling and server-authoritative state.",
        stack: ["React", "WebSockets", "Node.js", "Redis"],
        impact: "Distinguishes you from CRUD-only candidates in every panel.",
      },
    ],
  },
  {
    slug: "data-analyst",
    title: "Data Analyst",
    category: "Data & AI",
    tagline: "Turn messy data into decisions leadership trusts.",
    summary:
      "Analyst interviews are portfolio-first: SQL rounds, a case study, and questions about how you framed a metric. Dashboards alone are weak; decision impact is the signal.",
    coreSkills: ["SQL", "Excel", "Python", "Power BI", "Tableau", "Statistics", "Data Visualization", "Data Storytelling"],
    bonusSkills: ["Pandas", "A/B Testing", "BigQuery", "ETL", "Snowflake"],
    salaryIndia: "₹5–15 LPA",
    salaryGlobal: "$65k–$120k",
    demand: "High",
    roadmapSlug: "data-analyst",
    interviewTopics: ["Advanced SQL", "Metrics & experiment design", "Case study walkthrough", "Stakeholder communication"],
    projects: [
      {
        title: "Decision memo from public data",
        summary:
          "Analyse an open dataset, publish a 1-page memo with a clear recommendation, and quantify expected impact.",
        stack: ["SQL", "Python", "Pandas", "Power BI"],
        impact: "Mirrors the actual job: insight → recommendation → measured outcome.",
      },
      {
        title: "Funnel + cohort dashboard",
        summary:
          "Model events, build a funnel and retention cohorts, then flag the three biggest drop-offs with fixes.",
        stack: ["SQL", "BigQuery", "Tableau"],
        impact: "Shows you can build the metric layer hiring managers care about.",
      },
    ],
  },
  {
    slug: "data-scientist",
    title: "Data Scientist",
    category: "Data & AI",
    tagline: "Model uncertainty and make it useful.",
    summary:
      "Data science panels blend statistics, coding and business framing. A credible model with honest evaluation beats a fancy architecture with no baseline.",
    coreSkills: ["Python", "Pandas", "NumPy", "scikit-learn", "Statistics", "SQL", "Machine Learning", "Data Visualization"],
    bonusSkills: ["PyTorch", "A/B Testing", "Spark", "MLOps", "Deep Learning"],
    salaryIndia: "₹8–24 LPA",
    salaryGlobal: "$95k–$170k",
    demand: "High",
    roadmapSlug: "ai-data-scientist",
    interviewTopics: ["Statistics & probability", "Model evaluation", "Feature engineering", "Business case framing"],
    projects: [
      {
        title: "End-to-end prediction service",
        summary:
          "Baseline → tuned model → explained metrics → served endpoint with monitoring and drift notes.",
        stack: ["Python", "scikit-learn", "FastAPI", "Docker"],
        impact: "Proves you can ship a model, not just notebook it.",
      },
      {
        title: "Controlled experiment analysis",
        summary:
          "Design an A/B test, compute power, run the analysis, and write the decision recommendation.",
        stack: ["Python", "Pandas", "Statistics"],
        impact: "Directly maps to product experimentation interviews.",
      },
    ],
  },
  {
    slug: "ai-ml-engineer",
    title: "AI / ML Engineer",
    category: "Data & AI",
    tagline: "Put LLMs into production without the demo magic.",
    summary:
      "AI engineer postings now outpace ML research roles. The winning profile combines Python, retrieval systems, evaluation discipline, and cost/latency awareness.",
    coreSkills: ["Python", "PyTorch", "Machine Learning", "Deep Learning", "LLMs", "RAG", "LangChain", "MLOps"],
    bonusSkills: ["Docker", "AWS", "Hugging Face", "Prompt Engineering", "FastAPI"],
    salaryIndia: "₹10–30 LPA",
    salaryGlobal: "$110k–$195k",
    demand: "Very High",
    roadmapSlug: "ai-engineer",
    interviewTopics: ["Transformer & LLM fundamentals", "RAG architecture", "Evaluation & guardrails", "Serving cost/latency"],
    projects: [
      {
        title: "Evaluated RAG assistant",
        summary:
          "Document ingestion, hybrid retrieval, grounded citations, offline eval set and a latency/cost dashboard.",
        stack: ["Python", "LangChain", "PostgreSQL", "FastAPI"],
        impact: "Evaluation is the rarest AI-engineer skill — lead with it.",
      },
      {
        title: "Fine-tuned domain model",
        summary:
          "Fine-tune a small open model, compare against a prompted baseline, and publish the failure analysis.",
        stack: ["PyTorch", "Hugging Face", "MLOps"],
        impact: "Shows rigor beyond API-wrapper projects.",
      },
    ],
  },
  {
    slug: "devops-engineer",
    title: "DevOps Engineer",
    category: "Cloud & Security",
    tagline: "Make deploys boring and on-call quiet.",
    summary:
      "DevOps interviews favour people who have broken and fixed real infrastructure. Pipelines, IaC and incident stories carry more weight than certificates alone.",
    coreSkills: ["Linux", "Docker", "Kubernetes", "CI/CD", "AWS", "Terraform", "Bash", "Git"],
    bonusSkills: ["Prometheus", "Grafana", "GitHub Actions", "Nginx", "Serverless"],
    salaryIndia: "₹7–22 LPA",
    salaryGlobal: "$95k–$170k",
    demand: "High",
    roadmapSlug: "devops",
    interviewTopics: ["Linux & networking", "Kubernetes troubleshooting", "IaC and pipelines", "Incident & SLO design"],
    projects: [
      {
        title: "One-command production platform",
        summary:
          "Terraform-provisioned cluster running a containerised app with rolling deploys, TLS, alerts and backups.",
        stack: ["Terraform", "Kubernetes", "AWS", "GitHub Actions"],
        impact: "A reproducible platform repo is the strongest DevOps signal.",
      },
      {
        title: "Observability deep-dive",
        summary:
          "Instrument an app, define SLOs, build dashboards, then run a documented chaos experiment.",
        stack: ["Prometheus", "Grafana", "Docker"],
        impact: "Shows reliability thinking interviewers rarely see from juniors.",
      },
    ],
  },
  {
    slug: "cloud-engineer",
    title: "Cloud Engineer",
    category: "Cloud & Security",
    tagline: "Architect infrastructure that scales with the bill.",
    summary:
      "Cloud roles blend architecture and hands-on ops. Associate-level certification plus two deployed workloads and a cost-optimisation story is a strong fresher package.",
    coreSkills: ["AWS", "Linux", "Terraform", "Docker", "Kubernetes", "CI/CD", "Bash", "Serverless"],
    bonusSkills: ["Azure", "GCP", "Nginx", "Prometheus", "Network Security"],
    salaryIndia: "₹6–20 LPA",
    salaryGlobal: "$90k–$160k",
    demand: "High",
    roadmapSlug: "aws",
    interviewTopics: ["Core AWS services", "VPC & networking", "Cost and scaling", "Well-Architected trade-offs"],
    projects: [
      {
        title: "Serverless media pipeline",
        summary:
          "Upload → process → store → notify, built entirely with managed services and least-privilege IAM.",
        stack: ["AWS", "Serverless", "Bash"],
        impact: "Shows service selection judgement, not just console clicking.",
      },
      {
        title: "Cost-optimised multi-env estate",
        summary:
          "IaC for dev/stage/prod with tagging, budgets, autoscaling and a before/after cost report.",
        stack: ["Terraform", "AWS", "Grafana"],
        impact: "Cost ownership is a hiring differentiator for cloud teams.",
      },
    ],
  },
  {
    slug: "mobile-engineer",
    title: "Mobile Engineer",
    category: "Engineering",
    tagline: "Ship apps that deserve the home screen.",
    summary:
      "Mobile hiring is portfolio-led: store listings, offline behaviour, animation quality, and release process. Even one published app beats five tutorials.",
    coreSkills: ["React Native", "JavaScript", "TypeScript", "REST APIs", "Firebase", "Git", "React", "Expo"],
    bonusSkills: ["Flutter", "Android", "iOS", "Jest", "SwiftUI"],
    salaryIndia: "₹6–18 LPA",
    salaryGlobal: "$85k–$155k",
    demand: "High",
    roadmapSlug: "react-native",
    interviewTopics: ["App architecture", "Navigation & state", "Offline-first data", "Release & performance"],
    projects: [
      {
        title: "Published app with offline mode",
        summary:
          "Sync-capable app with push notifications, deep links, analytics and a real store release.",
        stack: ["React Native", "Expo", "Firebase"],
        impact: "The store listing is verifiable proof of follow-through.",
      },
      {
        title: "60fps animated UX",
        summary:
          "Rebuild a complex interaction with gesture-driven animation and a performance write-up.",
        stack: ["React Native", "Reanimated", "TypeScript"],
        impact: "Signals craft in a market full of mediocre mobile portfolios.",
      },
    ],
  },
  {
    slug: "qa-automation-engineer",
    title: "QA Automation Engineer",
    category: "Engineering",
    tagline: "Be the reason releases are trusted.",
    summary:
      "QA automation is an underrated entry point into product companies. Show a real test framework with CI reports and clear bug narratives.",
    coreSkills: ["Selenium", "Playwright", "JavaScript", "Unit Testing", "Postman", "Git", "Agile", "Performance Testing"],
    bonusSkills: ["Cypress", "Appium", "Python", "CI/CD", "REST APIs"],
    salaryIndia: "₹5–14 LPA",
    salaryGlobal: "$70k–$125k",
    demand: "High",
    roadmapSlug: "qa",
    interviewTopics: ["Test strategy", "Automation framework design", "API & contract testing", "Bug reporting quality"],
    projects: [
      {
        title: "E2E framework with CI reports",
        summary:
          "Page-object framework, seeded data, parallel runs, flake detection and published Allure report.",
        stack: ["Playwright", "TypeScript", "GitHub Actions"],
        impact: "Shows framework thinking plus pipeline integration.",
      },
      {
        title: "API contract test suite",
        summary:
          "Schema validation, negative cases and load test with a defect report from a real open-source API.",
        stack: ["Postman", "Python", "k6"],
        impact: "Demonstrates risk-based testing judgement.",
      },
    ],
  },
  {
    slug: "cybersecurity-analyst",
    title: "Cybersecurity Analyst",
    category: "Cloud & Security",
    tagline: "Hunt threats before they become headlines.",
    summary:
      "SOC and security analyst roles value labs, CTFs and detection write-ups. Documented investigations plus a home lab beat certification-only resumes.",
    coreSkills: ["Network Security", "OWASP", "Linux", "Penetration Testing", "SIEM", "Incident Response", "Burp Suite", "Computer Networks"],
    bonusSkills: ["Threat Modeling", "Cryptography", "Python", "AWS", "Incident Response"],
    salaryIndia: "₹5–16 LPA",
    salaryGlobal: "$80k–$145k",
    demand: "Very High",
    roadmapSlug: "cyber-security",
    interviewTopics: ["OWASP Top 10", "Network protocols & attacks", "Detection & triage", "Incident response playbook"],
    projects: [
      {
        title: "Home SOC lab",
        summary:
          "Centralised logging, simulated attacks, detection rules, and a triage report per alert.",
        stack: ["SIEM", "Linux", "Wireshark"],
        impact: "Directly mirrors day-one SOC responsibilities.",
      },
      {
        title: "Web app pentest report",
        summary:
          "Authorised test of a vulnerable lab app with CVSS scoring, PoCs and remediation guidance.",
        stack: ["Burp Suite", "OWASP", "Linux"],
        impact: "Professional report writing is what separates analysts from hobbyists.",
      },
    ],
  },
  {
    slug: "product-manager-tech",
    title: "Technical Product Manager",
    category: "Product",
    tagline: "Decide what's worth building, and why now.",
    summary:
      "Technical PM roles are competitive for freshers, but APM pipelines exist. Evidence of shipped scope, analytics literacy and crisp written thinking gets you in.",
    coreSkills: ["Product Analytics", "User Research", "Roadmapping", "PRD Writing", "Stakeholder Management", "Prioritization", "SQL", "Agile"],
    bonusSkills: ["A/B Testing", "Figma", "Data Storytelling", "Jira"],
    salaryIndia: "₹8–24 LPA",
    salaryGlobal: "$95k–$175k",
    demand: "Growing",
    roadmapSlug: "product-manager",
    interviewTopics: ["Product sense", "Metrics & experimentation", "Prioritisation trade-offs", "Execution & communication"],
    projects: [
      {
        title: "Teardown + PRD for a real app",
        summary:
          "Pick a product, diagnose a retention problem with data, and write the PRD plus success metrics.",
        stack: ["SQL", "Figma", "Notion"],
        impact: "Shows structured product thinking in a portable artifact.",
      },
      {
        title: "0→1 micro-launch",
        summary:
          "Ship a tiny product, instrument it, run 10 user interviews, and publish the learnings memo.",
        stack: ["Figma", "Product Analytics"],
        impact: "Closest possible proxy to the PM job.",
      },
    ],
  },
];

export const ROLE_BY_SLUG = new Map(ROLES.map((role) => [role.slug, role]));

export function getRole(slug: string): RoleDef | undefined {
  return ROLE_BY_SLUG.get(slug);
}

export const LEVELS = [
  { value: "student", label: "Student / pre-final year" },
  { value: "fresher", label: "Fresher / 0–1 years" },
  { value: "mid", label: "Early career / 1–4 years" },
  { value: "senior", label: "Experienced / 4+ years" },
] as const;

export function levelLabel(level: string): string {
  return LEVELS.find((entry) => entry.value === level)?.label ?? "Fresher / 0–1 years";
}
