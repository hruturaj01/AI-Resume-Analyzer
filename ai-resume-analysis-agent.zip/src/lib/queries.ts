import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, roadmapTasks, type AnalysisRow, type RoadmapTaskRow } from "@/db/schema";

export interface AnalysisSummary {
  publicId: string;
  candidateName: string | null;
  targetRoleTitle: string;
  level: string;
  weeks: number;
  overallScore: number;
  atsScore: number;
  readiness: string;
  createdAt: string;
}

export async function listAnalyses(limit = 20): Promise<AnalysisSummary[]> {
  const rows = await db
    .select({
      publicId: analyses.publicId,
      candidateName: analyses.candidateName,
      targetRoleTitle: analyses.targetRoleTitle,
      level: analyses.level,
      weeks: analyses.weeks,
      overallScore: analyses.overallScore,
      atsScore: analyses.atsScore,
      readiness: analyses.readiness,
      createdAt: analyses.createdAt,
    })
    .from(analyses)
    .orderBy(desc(analyses.createdAt))
    .limit(limit);

  return rows.map((row) => ({
    ...row,
    createdAt: row.createdAt.toISOString(),
  }));
}

export async function getAnalysis(
  publicId: string,
): Promise<{ analysis: AnalysisRow; tasks: RoadmapTaskRow[] } | null> {
  const [analysis] = await db.select().from(analyses).where(eq(analyses.publicId, publicId)).limit(1);
  if (!analysis) return null;
  const tasks = await db
    .select()
    .from(roadmapTasks)
    .where(eq(roadmapTasks.analysisId, analysis.id))
    .orderBy(roadmapTasks.phaseIndex, roadmapTasks.taskIndex);
  return { analysis, tasks };
}

export function analysisStats(rows: AnalysisSummary[]) {
  if (!rows.length) {
    return { count: 0, avgScore: 0, bestScore: 0, interviewReady: 0 };
  }
  const total = rows.reduce((sum, row) => sum + row.overallScore, 0);
  return {
    count: rows.length,
    avgScore: Math.round(total / rows.length),
    bestScore: Math.max(...rows.map((row) => row.overallScore)),
    interviewReady: rows.filter((row) => row.readiness === "interview-ready").length,
  };
}
