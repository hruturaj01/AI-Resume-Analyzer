import type { SkillCategory } from "./types";

export interface SkillDef {
  name: string;
  category: SkillCategory;
  aliases?: string[];
}

/**
 * Canonical skill dictionary. The agent matches resumes against this list
 * using alias expansion + word-boundary regexes so "javascript" never
 * falsely triggers "java", "postgresql" never triggers "sql", etc.
 */
export const SKILLS: SkillDef[] = [
  // Languages
  { name: "JavaScript", category: "Languages", aliases: ["javascript", "es6", "es2015", "ecmascript", "vanilla js"] },
  { name: "TypeScript", category: "Languages", aliases: ["typescript", "type script"] },
  { name: "Python", category: "Languages", aliases: ["python", "py3"] },
  { name: "Java", category: "Languages", aliases: ["java se", "core java", "java 8", "java 11", "java 17"] },
  { name: "C++", category: "Languages", aliases: ["c++", "cpp"] },
  { name: "C#", category: "Languages", aliases: ["c#", "csharp", ".net"] },
  { name: "Go", category: "Languages", aliases: ["golang", "go lang"] },
  { name: "Rust", category: "Languages", aliases: ["rust lang"] },
  { name: "Kotlin", category: "Languages", aliases: ["kotlin"] },
  { name: "Swift", category: "Languages", aliases: ["swift ios"] },
  { name: "PHP", category: "Languages", aliases: ["php"] },
  { name: "Ruby", category: "Languages", aliases: ["ruby on rails", "ruby"] },
  { name: "C", category: "Languages", aliases: ["c programming", "c language"] },
  { name: "SQL", category: "Languages", aliases: ["sql", "t-sql", "pl/sql"] },
  { name: "R", category: "Languages", aliases: ["r programming", "rstudio"] },
  { name: "Scala", category: "Languages", aliases: ["scala"] },
  { name: "Solidity", category: "Languages", aliases: ["solidity"] },
  { name: "Bash", category: "Languages", aliases: ["bash", "shell scripting", "shell script"] },

  // Frontend
  { name: "React", category: "Frontend", aliases: ["react", "react.js", "reactjs", "react hooks"] },
  { name: "Next.js", category: "Frontend", aliases: ["next.js", "nextjs", "next js"] },
  { name: "Vue", category: "Frontend", aliases: ["vue", "vue.js", "vuejs", "nuxt"] },
  { name: "Angular", category: "Frontend", aliases: ["angular", "angularjs"] },
  { name: "Svelte", category: "Frontend", aliases: ["svelte", "sveltekit"] },
  { name: "HTML", category: "Frontend", aliases: ["html", "html5", "semantic html"] },
  { name: "CSS", category: "Frontend", aliases: ["css", "css3", "flexbox", "css grid"] },
  { name: "Tailwind CSS", category: "Frontend", aliases: ["tailwind", "tailwindcss", "tailwind css"] },
  { name: "Sass", category: "Frontend", aliases: ["sass", "scss"] },
  { name: "Redux", category: "Frontend", aliases: ["redux", "redux toolkit", "rtk"] },
  { name: "React Query", category: "Frontend", aliases: ["react query", "tanstack query"] },
  { name: "Accessibility", category: "Frontend", aliases: ["accessibility", "a11y", "wcag", "aria"] },
  { name: "Vite", category: "Frontend", aliases: ["vite"] },
  { name: "Webpack", category: "Frontend", aliases: ["webpack"] },
  { name: "Three.js", category: "Frontend", aliases: ["three.js", "threejs", "webgl"] },
  { name: "Figma", category: "Frontend", aliases: ["figma"] },

  // Backend
  { name: "Node.js", category: "Backend", aliases: ["node.js", "nodejs", "node js", "node"] },
  { name: "Express", category: "Backend", aliases: ["express", "express.js", "expressjs"] },
  { name: "NestJS", category: "Backend", aliases: ["nestjs", "nest.js"] },
  { name: "Django", category: "Backend", aliases: ["django"] },
  { name: "Flask", category: "Backend", aliases: ["flask"] },
  { name: "FastAPI", category: "Backend", aliases: ["fastapi"] },
  { name: "Spring Boot", category: "Backend", aliases: ["spring boot", "springboot", "spring"] },
  { name: "Laravel", category: "Backend", aliases: ["laravel"] },
  { name: "GraphQL", category: "Backend", aliases: ["graphql", "apollo"] },
  { name: "REST APIs", category: "Backend", aliases: ["rest api", "restful", "rest apis", "api development"] },
  { name: "Microservices", category: "Backend", aliases: ["microservice", "microservices"] },
  { name: "WebSockets", category: "Backend", aliases: ["websocket", "websockets", "socket.io"] },
  { name: "Redis", category: "Backend", aliases: ["redis"] },
  { name: "PostgreSQL", category: "Backend", aliases: ["postgresql", "postgres"] },
  { name: "MySQL", category: "Backend", aliases: ["mysql", "mariadb"] },
  { name: "MongoDB", category: "Backend", aliases: ["mongodb", "mongo"] },
  { name: "Prisma", category: "Backend", aliases: ["prisma"] },
  { name: "Drizzle ORM", category: "Backend", aliases: ["drizzle orm", "drizzle"] },
  { name: "Kafka", category: "Backend", aliases: ["kafka"] },
  { name: "RabbitMQ", category: "Backend", aliases: ["rabbitmq"] },
  { name: "gRPC", category: "Backend", aliases: ["grpc"] },
  { name: "Authentication", category: "Backend", aliases: ["authentication", "oauth", "jwt", "auth0", "rbac"] },
  { name: "Caching", category: "Backend", aliases: ["caching", "cache invalidation", "cdn cache"] },
  { name: "System Design", category: "Backend", aliases: ["system design", "high level design", "scalable systems"] },

  // Data & AI
  { name: "Pandas", category: "Data & AI", aliases: ["pandas"] },
  { name: "NumPy", category: "Data & AI", aliases: ["numpy"] },
  { name: "scikit-learn", category: "Data & AI", aliases: ["scikit-learn", "sklearn", "scikit learn"] },
  { name: "TensorFlow", category: "Data & AI", aliases: ["tensorflow", "keras"] },
  { name: "PyTorch", category: "Data & AI", aliases: ["pytorch", "torch"] },
  { name: "Machine Learning", category: "Data & AI", aliases: ["machine learning", "ml models", "supervised learning"] },
  { name: "Deep Learning", category: "Data & AI", aliases: ["deep learning", "neural network", "neural networks", "cnn", "rnn"] },
  { name: "NLP", category: "Data & AI", aliases: ["nlp", "natural language processing"] },
  { name: "Computer Vision", category: "Data & AI", aliases: ["computer vision", "opencv"] },
  { name: "LLMs", category: "Data & AI", aliases: ["llm", "llms", "large language model", "gpt", "generative ai", "genai"] },
  { name: "Prompt Engineering", category: "Data & AI", aliases: ["prompt engineering", "prompt design"] },
  { name: "RAG", category: "Data & AI", aliases: ["rag", "retrieval augmented generation", "vector database", "embeddings"] },
  { name: "LangChain", category: "Data & AI", aliases: ["langchain", "langgraph", "llamaindex"] },
  { name: "Hugging Face", category: "Data & AI", aliases: ["hugging face", "huggingface", "transformers library"] },
  { name: "MLOps", category: "Data & AI", aliases: ["mlops", "model deployment", "mlflow"] },
  { name: "Power BI", category: "Data & AI", aliases: ["power bi", "powerbi"] },
  { name: "Tableau", category: "Data & AI", aliases: ["tableau"] },
  { name: "Excel", category: "Data & AI", aliases: ["excel", "spreadsheets", "google sheets", "vlookup"] },
  { name: "Statistics", category: "Data & AI", aliases: ["statistics", "statistical", "hypothesis testing", "regression analysis"] },
  { name: "A/B Testing", category: "Data & AI", aliases: ["a/b testing", "ab testing", "experimentation"] },
  { name: "Airflow", category: "Data & AI", aliases: ["airflow", "apache airflow"] },
  { name: "dbt", category: "Data & AI", aliases: ["dbt", "data build tool"] },
  { name: "Snowflake", category: "Data & AI", aliases: ["snowflake"] },
  { name: "BigQuery", category: "Data & AI", aliases: ["bigquery", "big query"] },
  { name: "Spark", category: "Data & AI", aliases: ["spark", "pyspark"] },
  { name: "Hadoop", category: "Data & AI", aliases: ["hadoop", "hive"] },
  { name: "Data Visualization", category: "Data & AI", aliases: ["data visualization", "dataviz", "data visualisation", "matplotlib", "seaborn"] },
  { name: "ETL", category: "Data & AI", aliases: ["etl", "elt", "data pipeline", "data pipelines"] },
  { name: "Data Modeling", category: "Data & AI", aliases: ["data modeling", "data modelling", "dimensional modeling"] },
  { name: "Data Storytelling", category: "Data & AI", aliases: ["data storytelling", "insight generation", "dashboards"] },

  // Cloud & DevOps
  { name: "AWS", category: "Cloud & DevOps", aliases: ["aws", "amazon web services", "ec2", "s3", "lambda"] },
  { name: "GCP", category: "Cloud & DevOps", aliases: ["gcp", "google cloud"] },
  { name: "Azure", category: "Cloud & DevOps", aliases: ["azure", "microsoft azure"] },
  { name: "Docker", category: "Cloud & DevOps", aliases: ["docker", "containerization", "containers"] },
  { name: "Kubernetes", category: "Cloud & DevOps", aliases: ["kubernetes", "k8s", "helm"] },
  { name: "Terraform", category: "Cloud & DevOps", aliases: ["terraform", "infrastructure as code", "iac"] },
  { name: "CI/CD", category: "Cloud & DevOps", aliases: ["ci/cd", "continuous integration", "continuous delivery", "jenkins"] },
  { name: "GitHub Actions", category: "Cloud & DevOps", aliases: ["github actions"] },
  { name: "Linux", category: "Cloud & DevOps", aliases: ["linux", "ubuntu", "unix"] },
  { name: "Nginx", category: "Cloud & DevOps", aliases: ["nginx"] },
  { name: "Prometheus", category: "Cloud & DevOps", aliases: ["prometheus"] },
  { name: "Grafana", category: "Cloud & DevOps", aliases: ["grafana", "observability", "monitoring"] },
  { name: "Serverless", category: "Cloud & DevOps", aliases: ["serverless", "cloud functions"] },

  // Mobile
  { name: "React Native", category: "Mobile", aliases: ["react native"] },
  { name: "Flutter", category: "Mobile", aliases: ["flutter", "dart"] },
  { name: "Android", category: "Mobile", aliases: ["android", "android studio"] },
  { name: "iOS", category: "Mobile", aliases: ["ios development", "ios app", "xcode"] },
  { name: "Firebase", category: "Mobile", aliases: ["firebase", "firestore"] },
  { name: "Expo", category: "Mobile", aliases: ["expo"] },
  { name: "SwiftUI", category: "Mobile", aliases: ["swiftui"] },
  { name: "Jetpack Compose", category: "Mobile", aliases: ["jetpack compose"] },

  // Testing & Tools
  { name: "Jest", category: "Testing & Tools", aliases: ["jest"] },
  { name: "Cypress", category: "Testing & Tools", aliases: ["cypress"] },
  { name: "Playwright", category: "Testing & Tools", aliases: ["playwright"] },
  { name: "Selenium", category: "Testing & Tools", aliases: ["selenium"] },
  { name: "Appium", category: "Testing & Tools", aliases: ["appium"] },
  { name: "Postman", category: "Testing & Tools", aliases: ["postman"] },
  { name: "Git", category: "Testing & Tools", aliases: ["git", "version control"] },
  { name: "GitHub", category: "Testing & Tools", aliases: ["github", "github profile"] },
  { name: "Jira", category: "Testing & Tools", aliases: ["jira", "confluence"] },
  { name: "Agile", category: "Testing & Tools", aliases: ["agile", "sprint planning", "scrum"] },
  { name: "Unit Testing", category: "Testing & Tools", aliases: ["unit testing", "unit tests", "pytest", "vitest", "junit"] },
  { name: "Performance Testing", category: "Testing & Tools", aliases: ["performance testing", "load testing", "jmeter", "k6"] },

  // Core CS
  { name: "Data Structures", category: "Core CS", aliases: ["data structures", "dsa", "linked list", "binary tree"] },
  { name: "Algorithms", category: "Core CS", aliases: ["algorithms", "algorithm", "dynamic programming", "combinatorics"] },
  { name: "Object-Oriented Programming", category: "Core CS", aliases: ["object oriented", "oop", "oops", "solid principles"] },
  { name: "Operating Systems", category: "Core CS", aliases: ["operating systems", "operating system", "process scheduling"] },
  { name: "Computer Networks", category: "Core CS", aliases: ["computer networks", "networking fundamentals", "tcp/ip"] },
  { name: "DBMS", category: "Core CS", aliases: ["dbms", "database management", "normalization", "indexing"] },
  { name: "Distributed Systems", category: "Core CS", aliases: ["distributed systems", "consistency", "sharding"] },

  // Security
  { name: "Penetration Testing", category: "Security", aliases: ["penetration testing", "pen testing", "ethical hacking"] },
  { name: "OWASP", category: "Security", aliases: ["owasp", "top 10"] },
  { name: "SIEM", category: "Security", aliases: ["siem", "splunk", "soc analyst"] },
  { name: "Threat Modeling", category: "Security", aliases: ["threat modeling", "threat model"] },
  { name: "Network Security", category: "Security", aliases: ["network security", "firewall", "wireshark"] },
  { name: "Burp Suite", category: "Security", aliases: ["burp suite", "burp"] },
  { name: "Incident Response", category: "Security", aliases: ["incident response", "forensics", "malware analysis"] },
  { name: "Cryptography", category: "Security", aliases: ["cryptography", "encryption"] },

  // Product
  { name: "Product Analytics", category: "Product", aliases: ["product analytics", "mixpanel", "amplitude"] },
  { name: "User Research", category: "Product", aliases: ["user research", "user interviews", "usability testing"] },
  { name: "Roadmapping", category: "Product", aliases: ["roadmap", "roadmapping", "product roadmap"] },
  { name: "PRD Writing", category: "Product", aliases: ["prd", "product requirements", "spec writing"] },
  { name: "Stakeholder Management", category: "Product", aliases: ["stakeholder management", "cross-functional"] },
  { name: "Prioritization", category: "Product", aliases: ["prioritization", "rice framework", "backlog grooming"] },
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  "Languages",
  "Frontend",
  "Backend",
  "Data & AI",
  "Cloud & DevOps",
  "Mobile",
  "Testing & Tools",
  "Core CS",
  "Security",
  "Product",
];

export const SKILL_BY_NAME = new Map(SKILLS.map((skill) => [skill.name.toLowerCase(), skill]));

export function findSkill(name: string): SkillDef | undefined {
  return SKILL_BY_NAME.get(name.trim().toLowerCase());
}
