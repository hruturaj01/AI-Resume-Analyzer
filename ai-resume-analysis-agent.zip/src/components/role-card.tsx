import Link from "next/link";
import type { RoleDef } from "@/lib/roles";

export function RoleCard({ role, compact = false }: { role: RoleDef; compact?: boolean }) {
  return (
    <Link
      href={`/roles/${role.slug}`}
      className="card group flex h-full flex-col p-5 transition duration-200 hover:-translate-y-0.5 hover:border-white/20 hover:bg-white/[0.055]"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="label">{role.category}</p>
          <h3 className="mt-2 text-[17px] font-bold leading-tight tracking-[-0.02em] text-white">{role.title}</h3>
        </div>
        <span className="chip shrink-0 border-accent/25 bg-accent/10 text-[10px] text-accent-soft">{role.demand}</span>
      </div>
      <p className="mt-2.5 text-[13px] leading-relaxed text-white/50">{role.tagline}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">
        {role.coreSkills.slice(0, compact ? 3 : 4).map((skill) => (
          <span key={skill} className="chip">
            {skill}
          </span>
        ))}
        {role.coreSkills.length > (compact ? 3 : 4) ? (
          <span className="chip text-white/45">+{role.coreSkills.length - (compact ? 3 : 4)}</span>
        ) : null}
      </div>
      <div className="mt-auto flex items-center justify-between gap-2 border-t border-white/8 pt-3.5 text-[11.5px]">
        <span className="font-mono text-white/45">{role.salaryIndia}</span>
        <span className="inline-flex items-center gap-1 font-semibold text-accent/85 transition group-hover:text-accent">
          Track
          <span aria-hidden="true" className="transition group-hover:translate-x-0.5">→</span>
        </span>
      </div>
    </Link>
  );
}
