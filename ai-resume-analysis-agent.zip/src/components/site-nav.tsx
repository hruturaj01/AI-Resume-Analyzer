import Link from "next/link";
import { Wordmark } from "./logo";

const LINKS = [
  { href: "/#analyzer", label: "Analyzer" },
  { href: "/roles", label: "Role tracks" },
  { href: "/dashboard", label: "My reports" },
  { href: "/#how", label: "How it works" },
];

export function SiteNav() {
  return (
    <header className="no-print sticky top-0 z-40 border-b border-line bg-ink-950/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-5">
        <Link href="/" className="shrink-0" aria-label="Placemate home">
          <Wordmark />
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-full px-3.5 py-2 text-[13px] font-medium text-white/65 transition hover:bg-white/5 hover:text-white"
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <Link href="/#analyzer" className="btn-primary shrink-0 text-[13px]">
          Analyze resume
          <span aria-hidden="true">→</span>
        </Link>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="no-print mt-24 border-t border-line">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-12 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Wordmark />
          <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-white/50">
            The placement agent that reads your resume like a hiring panel, then hands you the exact roadmap to get
            shortlisted.
          </p>
        </div>
        <div>
          <p className="label">Product</p>
          <ul className="mt-4 space-y-2.5 text-[13px] text-white/60">
            <li><Link href="/#analyzer" className="hover:text-white">Resume analyzer</Link></li>
            <li><Link href="/roles" className="hover:text-white">Role tracks</Link></li>
            <li><Link href="/dashboard" className="hover:text-white">Saved reports</Link></li>
          </ul>
        </div>
        <div>
          <p className="label">Tracks</p>
          <ul className="mt-4 space-y-2.5 text-[13px] text-white/60">
            <li><Link href="/roles/frontend-engineer" className="hover:text-white">Frontend</Link></li>
            <li><Link href="/roles/backend-engineer" className="hover:text-white">Backend</Link></li>
            <li><Link href="/roles/data-analyst" className="hover:text-white">Data analyst</Link></li>
            <li><Link href="/roles/ai-ml-engineer" className="hover:text-white">AI / ML engineer</Link></li>
          </ul>
        </div>
        <div>
          <p className="label">Privacy</p>
          <p className="mt-4 text-[13px] leading-relaxed text-white/50">
            Your resume is analysed on the server, never sold or shared. Delete any report from your dashboard at any
            time.
          </p>
        </div>
      </div>
      <div className="border-t border-line">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-5 py-5 text-[12px] text-white/35 sm:flex-row">
          <p>© {new Date().getFullYear()} Placemate. Built for placement season.</p>
          <p className="font-mono text-[11px]">agent v2 · parser + role-graph scorer</p>
        </div>
      </div>
    </footer>
  );
}
