"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { LEVELS, ROLES, getRole } from "@/lib/roles";
import { SAMPLES } from "@/lib/samples";

const AGENT_STEPS = [
  "Parsing resume structure",
  "Extracting skills & entities",
  "Auditing ATS + impact signals",
  "Scoring 12 placement tracks",
  "Synthesising your roadmap",
];

const WEEK_OPTIONS = [4, 8, 12, 16, 20];

interface AnalyzeFormProps {
  initialRole?: string;
}

export function AnalyzeForm({ initialRole }: AnalyzeFormProps) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [resumeText, setResumeText] = useState("");
  const [targetRole, setTargetRole] = useState(initialRole && getRole(initialRole) ? initialRole : "auto");
  const [level, setLevel] = useState("fresher");
  const [weeks, setWeeks] = useState(12);
  const [fileName, setFileName] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!submitting) return;
    const timer = window.setInterval(() => {
      setStep((current) => (current < AGENT_STEPS.length - 1 ? current + 1 : current));
    }, 700);
    return () => window.clearInterval(timer);
  }, [submitting]);

  const selectedRole = targetRole === "auto" ? null : getRole(targetRole);
  const charCount = resumeText.trim().length;
  const ready = charCount >= 120;

  function loadSample(id: string) {
    const sample = SAMPLES.find((entry) => entry.id === id);
    if (!sample) return;
    setResumeText(sample.text);
    setTargetRole(sample.role);
    setFileName(`${sample.id}-sample.txt`);
    setError(null);
  }

  async function readFile(file: File) {
    const nameLower = file.name.toLowerCase();
    if (/\.(pdf|docx?|pages|rtf)$/.test(nameLower)) {
      setError(
        "PDF/Word files can't be read directly in the browser. Open the file, copy the text, and paste it below — every section is preserved.",
      );
      return;
    }
    if (file.size > 400_000) {
      setError("That file is too large. Keep it under 400 KB of plain text.");
      return;
    }
    const text = await file.text();
    setResumeText(text);
    setFileName(file.name);
    setError(null);
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!ready || submitting) {
      if (!ready) setError("Paste at least 120 characters so the agent has enough signal.");
      return;
    }
    setError(null);
    setSubmitting(true);
    setStep(0);
    const startedAt = Date.now();
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText, targetRole, level, weeks, fileName }),
      });
      const data = (await response.json()) as { publicId?: string; error?: string };
      if (!response.ok || !data.publicId) {
        throw new Error(data.error ?? "Analysis failed. Please try again.");
      }
      const elapsed = Date.now() - startedAt;
      const minimum = 1800;
      if (elapsed < minimum) await new Promise((resolve) => setTimeout(resolve, minimum - elapsed));
      setStep(AGENT_STEPS.length);
      await new Promise((resolve) => setTimeout(resolve, 320));
      router.push(`/report/${data.publicId}?fresh=1`);
    } catch (submitError) {
      setSubmitting(false);
      setError(submitError instanceof Error ? submitError.message : "Something went wrong. Please try again.");
    }
  }

  if (submitting) {
    return (
      <div className="card p-6 sm:p-7">
        <div className="flex items-center justify-between">
          <p className="label">Agent run in progress</p>
          <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-accent">
            <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-accent" />
            live
          </span>
        </div>
        <h3 className="mt-3 text-xl font-bold tracking-[-0.02em] text-white">Reading your resume the way a panel does…</h3>
        <div className="mt-6 space-y-2.5">
          {AGENT_STEPS.map((label, index) => {
            const done = index < step;
            const active = index === step;
            return (
              <div
                key={label}
                className={`flex items-center gap-3 rounded-xl border px-3.5 py-3 transition ${
                  done
                    ? "border-accent/25 bg-accent/8"
                    : active
                      ? "border-white/14 bg-white/5"
                      : "border-white/6 bg-white/[0.015] opacity-55"
                }`}
              >
                <span
                  className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border text-[11px] font-bold ${
                    done
                      ? "border-accent/40 bg-accent text-[#0b0f04]"
                      : active
                        ? "border-accent/40 text-accent"
                        : "border-white/15 text-white/35"
                  }`}
                >
                  {done ? "✓" : active ? <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-accent" /> : index + 1}
                </span>
                <span className={`text-[13px] ${done || active ? "text-white/90" : "text-white/45"}`}>{label}</span>
                {done ? <span className="ml-auto font-mono text-[10px] text-accent/80">done</span> : null}
              </div>
            );
          })}
        </div>
        <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-white/8">
          <div
            className="h-full rounded-full bg-gradient-to-r from-accent-soft to-accent-dim transition-all duration-500"
            style={{ width: `${Math.min(100, ((step + 1) / AGENT_STEPS.length) * 100)}%` }}
          />
        </div>
        <p className="mt-4 text-[12px] leading-relaxed text-white/40">
          Scoring {ROLES.length} role tracks, checking ATS parseability and sequencing your weekly plan. Takes a few
          seconds.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="card p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <p className="label">New analysis</p>
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/35">step 1 of 2</span>
      </div>
      <h2 className="mt-2 text-[22px] font-bold leading-tight tracking-[-0.025em] text-white">
        Drop your resume. Get the plan.
      </h2>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {SAMPLES.map((sample) => (
          <button
            key={sample.id}
            type="button"
            onClick={() => loadSample(sample.id)}
            title={sample.blurb}
            className="chip transition hover:border-accent/40 hover:bg-accent/10 hover:text-accent-soft"
          >
            <span aria-hidden="true">✦</span> {sample.label}
          </button>
        ))}
      </div>

      <div
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={async (event) => {
          event.preventDefault();
          setDragging(false);
          const file = event.dataTransfer.files?.[0];
          if (file) await readFile(file);
        }}
        className={`mt-3 rounded-xl border transition ${dragging ? "border-accent/60 bg-accent/5" : "border-white/10 bg-ink-950/60"}`}
      >
        <textarea
          value={resumeText}
          onChange={(event) => {
            setResumeText(event.target.value);
            setError(null);
          }}
          placeholder={
            "Paste your full resume text here…\n\nName, contact links, summary, skills, experience, projects, education.\n\nTip: click a sample above to see a full report instantly."
          }
          spellCheck={false}
          className="h-52 w-full resize-y bg-transparent px-4 py-3.5 font-mono text-[12px] leading-relaxed text-white/85 placeholder:text-white/28 focus:outline-none"
        />
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/8 px-3 py-2">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11.5px] font-semibold text-white/65 transition hover:bg-white/5 hover:text-white"
          >
            <span aria-hidden="true">↑</span> Upload .txt / .md
          </button>
          <span className={`font-mono text-[10.5px] ${ready ? "text-accent/80" : "text-white/35"}`}>
            {charCount.toLocaleString()} chars {fileName ? `· ${fileName.slice(0, 24)}` : ""}
          </span>
          <input
            ref={fileRef}
            type="file"
            accept=".txt,.md,.markdown,.text,.json,.csv,text/plain"
            className="hidden"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              if (file) await readFile(file);
            }}
          />
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="target-role" className="label">
            Target role
          </label>
          <select
            id="target-role"
            value={targetRole}
            onChange={(event) => setTargetRole(event.target.value)}
            className="input mt-1.5"
          >
            <option value="auto">Auto — let the agent decide</option>
            {ROLES.map((role) => (
              <option key={role.slug} value={role.slug}>
                {role.title}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="level" className="label">
            Experience level
          </label>
          <select id="level" value={level} onChange={(event) => setLevel(event.target.value)} className="input mt-1.5">
            {LEVELS.map((entry) => (
              <option key={entry.value} value={entry.value}>
                {entry.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-4">
        <div className="flex items-center justify-between">
          <p className="label">Placement deadline</p>
          <span className="font-mono text-[11px] text-white/55">{weeks} weeks</span>
        </div>
        <div className="mt-2 grid grid-cols-5 gap-1.5">
          {WEEK_OPTIONS.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setWeeks(option)}
              className={`rounded-lg border py-2 text-[12px] font-semibold transition ${
                weeks === option
                  ? "border-accent/50 bg-accent/15 text-accent-soft"
                  : "border-white/10 bg-white/[0.02] text-white/55 hover:border-white/25 hover:text-white"
              }`}
            >
              {option}w
            </button>
          ))}
        </div>
      </div>

      {selectedRole ? (
        <div className="mt-4 rounded-xl border border-white/8 bg-white/[0.025] p-3">
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">
            {selectedRole.title} requires
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {selectedRole.coreSkills.slice(0, 7).map((skill) => (
              <span key={skill} className="chip">
                {skill}
              </span>
            ))}
          </div>
        </div>
      ) : (
        <div className="mt-4 rounded-xl border border-white/8 bg-white/[0.025] p-3 text-[12px] leading-relaxed text-white/50">
          <span className="text-accent">Auto mode.</span> The agent scores your resume against all {ROLES.length} tracks and
          routes you to the highest-leverage one.
        </div>
      )}

      {error ? (
        <p className="mt-3 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-[12px] leading-relaxed text-rose">
          {error}
        </p>
      ) : null}

      <button type="submit" disabled={!ready} className="btn-primary mt-4 w-full py-3 text-[14px]">
        {ready ? "Run the placement agent" : `Add ${Math.max(0, 120 - charCount)} more characters`}
        <span aria-hidden="true">→</span>
      </button>
      <p className="mt-2.5 text-center text-[11px] text-white/32">
        Free · no sign-up · your report gets a private link you can revisit
      </p>
    </form>
  );
}
