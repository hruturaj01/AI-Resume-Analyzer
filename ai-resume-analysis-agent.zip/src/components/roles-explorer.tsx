"use client";

import { useMemo, useState } from "react";
import { RoleCard } from "@/components/role-card";
import { ROLES } from "@/lib/roles";

const CATEGORIES = ["All", "Engineering", "Data & AI", "Cloud & Security", "Product"] as const;

export function RolesExplorer() {
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return ROLES.filter((role) => {
      const matchesCategory = category === "All" || role.category === category;
      const haystack = `${role.title} ${role.tagline} ${role.coreSkills.join(" ")}`.toLowerCase();
      return matchesCategory && (!query.trim() || haystack.includes(query.trim().toLowerCase()));
    });
  }, [category, query]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((entry) => (
            <button
              key={entry}
              type="button"
              onClick={() => setCategory(entry)}
              className={`rounded-full border px-3 py-1.5 text-[12px] font-semibold transition ${
                category === entry
                  ? "border-accent/50 bg-accent/15 text-accent-soft"
                  : "border-white/10 bg-white/[0.02] text-white/55 hover:border-white/25 hover:text-white"
              }`}
            >
              {entry}
            </button>
          ))}
        </div>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search role or skill…"
          className="input max-w-[240px]"
          aria-label="Search role tracks"
        />
      </div>

      <p className="mt-3 font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/30">
        {filtered.length} track{filtered.length === 1 ? "" : "s"}
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((role) => (
          <RoleCard key={role.slug} role={role} />
        ))}
      </div>

      {!filtered.length ? (
        <div className="card mt-4 p-8 text-center">
          <p className="text-[13.5px] text-white/60">No track matches “{query}”.</p>
          <button
            type="button"
            onClick={() => {
              setQuery("");
              setCategory("All");
            }}
            className="btn-ghost mt-3"
          >
            Reset filters
          </button>
        </div>
      ) : null}
    </div>
  );
}
