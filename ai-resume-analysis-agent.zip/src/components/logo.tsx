export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="url(#pm-mark)" />
      <path
        d="M10 23V9.5h6.4c3 0 5.1 1.9 5.1 4.8s-2.1 4.9-5.1 4.9h-2.6V23H10Z"
        fill="#0a0c07"
      />
      <circle cx="23" cy="22.5" r="2.5" fill="#0a0c07" />
      <defs>
        <linearGradient id="pm-mark" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop stopColor="#E4FFA8" />
          <stop offset="0.55" stopColor="#C9F75A" />
          <stop offset="1" stopColor="#8ED0A8" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export function Wordmark() {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="text-[17px] font-extrabold tracking-[-0.02em] text-white">
        place<span className="text-accent">mate</span>
      </span>
    </span>
  );
}
