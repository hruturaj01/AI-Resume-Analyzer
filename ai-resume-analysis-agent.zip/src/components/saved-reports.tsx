"use client";

import Link from "next/link";
import { useState } from "react";
import { ScoreBar } from "@/components/score-ring";

export interface SavedReport {
  publicId: string;
  candidateName: string | null;
  targetRoleTitle: string;
  level: string;
  weeks: number;
  overallScore: number;
  atsScore: number;
  readiness: string;
  createdLabel: string;
}

const READINESS_LABEL: Record<string, string> = {
  "interview-ready": "Interview ready",
  "near-ready": "Near ready",
  developing: "Developing",
  foundation: "Foundation",
};

export function SavedReports({ items, stats }: { items: SavedReport[]; stats: { count: number; avgScore: number; bestScore: number; interviewReady: number } }) {
  const [reports, setReports] = useState(items);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function remove(publicId: string) {
    if (!window.confirm("Delete this report and its roadmap progress? This cannot be undone.")) return;
    setDeleting(publicId);
    setError(null);
    try {
      const response = await fetch(`/api/analyses/${publicId}`, { method: "DELETE" });
      if (!response.ok) throw new Error("delete failed");
      setReports((prev) => prev.filter((report) => report.publicId !== publicId));
    } catch {
      setError("Could not delete that report. Try again.");
    } finally {
      setDeleting(null);
    }
  }

  if (!reports.length) {
    return (
      <div className="card flex flex-col items-start p-8">
        <span className="chip chip-accent">No reports yet</span>
        <h2 className="mt-3 text-[22px] font-extrabold tracking-[-0.03em] text-white">Your first analysis is 30 seconds away.</h2>
        <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-white/50">
          Paste your resume, choose a track (or let the agent decide), and get a scored report with a week-by-week
          placement roadmap. Every run is saved here with its progress.
        </p>
        <Link href="/#analyzer" className="btn-primary mt-5">
          Run the placement agent →
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="grid gap-2.5 sm:grid-cols-4">
        {[
          { label: "Reports run", value: stats.count },
          { label: "Average score", value: stats.avgScore },
          { label: "Best score", value: stats.bestScore },
          { label: "Interview ready", value: stats.interviewReady },
        ].map((tile) => (
          <div key={tile.label} className="card-flat px-4 py-3">
            <p className="text-[22px] font-extrabold tracking-[-0.03em] text-white">{tile.value}</p>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-white/38">{tile.label}</p>
          </div>
        ))}
      </div>

      {error ? (
        <p className="mt-3 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-[12px] text-rose">{error}</p>
      ) : null}

      <div className="mt-4 space-y-2.5">
        {reports.map((report) => (
          <div key={report.publicId} className="card flex flex-wrap items-center gap-4 p-5">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.03]">
              <span className="text-[15px] font-extrabold tracking-tight text-white">{report.overallScore}</span>
            </div>
            <div className="min-w-[180px] flex-1">
              <Link href={`/report/${report.publicId}`} className="text-[14px] font-semibold text-white hover:text-accent-soft">
                {report.targetRoleTitle}
              </Link>
              <p className="mt-0.5 text-[11.5px] text-white/40">
                {report.candidateName ?? "Candidate"} · {report.createdLabel} · {report.weeks}-week plan
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="chip text-[10px]">{READINESS_LABEL[report.readiness] ?? report.readiness}</span>
                <span className="chip text-[10px]">ATS {report.atsScore}</span>
              </div>
            </div>
            <div className="w-32">
              <ScoreBar
                score={report.overallScore}
                tone={report.overallScore >= 74 ? "accent" : report.overallScore >= 58 ? "sky" : "rose"}
              />
            </div>
            <div className="flex items-center gap-2">
              <Link href={`/report/${report.publicId}`} className="btn-ghost text-[11.5px]">
                Open →
              </Link>
              <button
                type="button"
                onClick={() => remove(report.publicId)}
                disabled={deleting === report.publicId}
                className="rounded-full border border-rose/25 bg-rose/8 px-3 py-2 text-[11.5px] font-semibold text-rose/85 transition hover:border-rose/50 hover:bg-rose/15 disabled:opacity-50"
                aria-label={`Delete report for ${report.targetRoleTitle}`}
              >
                {deleting === report.publicId ? "…" : "Delete"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
