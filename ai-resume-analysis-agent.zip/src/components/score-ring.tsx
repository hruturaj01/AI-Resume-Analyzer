interface ScoreRingProps {
  score: number;
  size?: number;
  stroke?: number;
  caption?: string;
  suffix?: string;
}

function toneFor(score: number): { from: string; to: string; text: string } {
  if (score >= 74) return { from: "#E4FFA8", to: "#9BCC33", text: "#D7FF7A" };
  if (score >= 58) return { from: "#BFD3FF", to: "#7DA2FF", text: "#B9CDFF" };
  return { from: "#FFC2B4", to: "#FF8F7A", text: "#FFB4A5" };
}

export function ScoreRing({ score, size = 148, stroke = 10, caption, suffix = "/100" }: ScoreRingProps) {
  const clamped = Math.max(0, Math.min(100, score));
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * (1 - clamped / 100);
  const tone = toneFor(clamped);
  const id = `ring-${size}-${clamped}`;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={`url(#${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={dash}
          style={{ transition: "stroke-dashoffset 700ms cubic-bezier(0.22,1,0.36,1)" }}
        />
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2={size} y2={size} gradientUnits="userSpaceOnUse">
            <stop stopColor={tone.from} />
            <stop offset="1" stopColor={tone.to} />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-semibold tracking-[-0.04em]" style={{ color: tone.text, fontSize: size * 0.29 }}>
          {Math.round(clamped)}
        </span>
        {caption ? (
          <span className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.16em] text-white/45">{caption}</span>
        ) : (
          <span className="font-mono text-[10px] tracking-[0.1em] text-white/40">{suffix}</span>
        )}
      </div>
    </div>
  );
}

export function ScoreBar({ score, tone = "accent" }: { score: number; tone?: "accent" | "sky" | "rose" | "mint" }) {
  const palette = {
    accent: "from-accent-soft to-accent-dim",
    sky: "from-sky to-[#5f86ff]",
    rose: "from-rose to-[#ff6f56]",
    mint: "from-mint to-[#35c795]",
  } as const;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/8">
      <div
        className={`h-full rounded-full bg-gradient-to-r ${palette[tone]}`}
        style={{ width: `${Math.max(4, Math.min(100, score))}%` }}
      />
    </div>
  );
}
