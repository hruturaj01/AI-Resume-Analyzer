"use client";

import Link from "next/link";
import { useMemo, useState, type ReactNode } from "react";
import { ScoreBar, ScoreRing } from "@/components/score-ring";
import type { AnalysisReport, AtsFinding, RoadmapPhase } from "@/lib/types";

interface TaskRow {
  id: number;
  phaseIndex: number;
  taskIndex: number;
  title: string;
  done: boolean;
}

interface ReportViewProps {
  publicId: string;
  createdAtLabel: string;
  report: AnalysisReport;
  tasks: TaskRow[];
  fresh: boolean;
}

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "roadmap", label: "Roadmap" },
  { id: "roles", label: "Role fit" },
  { id: "interview", label: "Interview prep" },
  { id: "portfolio", label: "Portfolio" },
] as const;

type TabId = (typeof TABS)[number]["id"];

const STATUS_META: Record<AtsFinding["status"], { icon: string; className: string; label: string }> = {
  pass: { icon: "✓", className: "border-accent/30 bg-accent/12 text-accent", label: "Pass" },
  warn: { icon: "!", className: "border-amber-300/30 bg-amber-300/12 text-amber-300", label: "Warn" },
  fail: { icon: "×", className: "border-rose/35 bg-rose/12 text-rose", label: "Fail" },
};

const SEVERITY_META: Record<"critical" | "high" | "medium", string> = {
  critical: "border-rose/30 bg-rose/10 text-rose",
  high: "border-amber-300/30 bg-amber-300/10 text-amber-300",
  medium: "border-sky/30 bg-sky/10 text-sky",
};

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`card p-5 ${className}`}>{children}</div>;
}

function PhaseTasks({
  phase,
  rows,
  state,
  pending,
  onToggle,
}: {
  phase: RoadmapPhase;
  rows: TaskRow[];
  state: Record<number, boolean>;
  pending: Set<number>;
  onToggle: (id: number) => void;
}) {
  const done = rows.filter((row) => state[row.id]).length;
  const pct = rows.length ? Math.round((done / rows.length) * 100) : 0;

  return (
    <div className="card overflow-hidden">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-white/8 p-5">
        <div className="flex gap-3.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-accent/25 bg-accent/10 font-mono text-[12px] font-semibold text-accent">
            {phase.index}
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-[16px] font-bold tracking-[-0.02em] text-white">{phase.title}</h3>
              <span className="chip text-[10px] text-white/55">{phase.timeframe}</span>
            </div>
            <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-white/48">{phase.focus}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-24">
            <ScoreBar score={pct} tone={pct === 100 ? "mint" : "accent"} />
          </div>
          <span className="font-mono text-[11px] text-white/50">
            {done}/{rows.length}
          </span>
        </div>
      </div>

      <div className="divide-y divide-white/6">
        {rows.map((row) => {
          const detail = phase.tasks[row.taskIndex];
          const checked = Boolean(state[row.id]);
          return (
            <div key={row.id} className="flex gap-3 px-5 py-3.5 transition hover:bg-white/[0.02]">
              <button
                type="button"
                onClick={() => onToggle(row.id)}
                aria-pressed={checked}
                aria-label={`${checked ? "Mark incomplete" : "Mark complete"}: ${row.title}`}
                className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border text-[11px] font-bold transition ${
                  checked
                    ? "border-accent bg-accent text-[#0b0f04]"
                    : "border-white/25 bg-white/[0.03] text-transparent hover:border-accent/60"
                } ${pending.has(row.id) ? "opacity-60" : ""}`}
              >
                ✓
              </button>
              <div className="min-w-0 flex-1">
                <p className={`text-[13.5px] font-semibold leading-snug ${checked ? "text-white/38 line-through" : "text-white/90"}`}>
                  {row.title}
                </p>
                {detail ? (
                  <p className={`mt-1 text-[12px] leading-relaxed ${checked ? "text-white/28" : "text-white/48"}`}>
                    {detail.detail}
                  </p>
                ) : null}
                {detail?.resources.length ? (
                  <div className="mt-1.5 flex flex-wrap gap-2">
                    {detail.resources.map((resource) => (
                      <a
                        key={resource.url}
                        href={resource.url}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="inline-flex items-center gap-1 text-[11px] font-medium text-accent/80 underline decoration-accent/25 underline-offset-2 transition hover:text-accent"
                      >
                        {resource.label} <span aria-hidden="true">↗</span>
                      </a>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      <div className="border-t border-white/8 bg-white/[0.02] px-5 py-2.5">
        <p className="text-[11.5px] text-white/40">
          <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-accent/60">Outcome</span>{" "}
          {phase.outcome}
        </p>
      </div>
    </div>
  );
}

export function ReportView({ publicId, createdAtLabel, report, tasks, fresh }: ReportViewProps) {
  const [tab, setTab] = useState<TabId>("overview");
  const [copied, setCopied] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pending, setPending] = useState<Set<number>>(new Set());
  const [state, setState] = useState<Record<number, boolean>>(() => {
    const initial: Record<number, boolean> = {};
    for (const row of tasks) initial[row.id] = row.done;
    return initial;
  });

  const completed = tasks.filter((row) => state[row.id]).length;
  const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
  const bestMatch = useMemo(
    () => report.roleMatches.reduce((best, match) => (match.match > best.match ? match : best), report.roleMatches[0]),
    [report.roleMatches],
  );

  const rowsByPhase = useMemo(() => {
    const map = new Map<number, TaskRow[]>();
    for (const row of tasks) {
      const list = map.get(row.phaseIndex) ?? [];
      list.push(row);
      map.set(row.phaseIndex, list);
    }
    return map;
  }, [tasks]);

  async function toggle(id: number) {
    const next = !state[id];
    setState((prev) => ({ ...prev, [id]: next }));
    setPending((prev) => new Set(prev).add(id));
    setSaveError(null);
    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ done: next }),
      });
      if (!response.ok) throw new Error("save failed");
    } catch {
      setState((prev) => ({ ...prev, [id]: !next }));
      setSaveError("Couldn't save that tick — check your connection and try again.");
    } finally {
      setPending((prev) => {
        const nextSet = new Set(prev);
        nextSet.delete(id);
        return nextSet;
      });
    }
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-8">
      {fresh ? (
        <div className="no-print mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-accent/25 bg-accent/8 px-4 py-2.5">
          <p className="text-[12.5px] text-accent-soft">
            <span className="mr-1.5" aria-hidden="true">✦</span>
            Analysis complete. This report is saved — progress ticks persist when you come back.
          </p>
          <Link href="/dashboard" className="text-[12px] font-semibold text-accent underline underline-offset-2">
            View all reports →
          </Link>
        </div>
      ) : null}

      {/* Header */}
      <div className="card overflow-hidden">
        <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[1fr_auto]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="label">Placement report</span>
              <span className="h-1 w-1 rounded-full bg-white/25" />
              <span className="font-mono text-[10.5px] text-white/40">{createdAtLabel}</span>
              <span className="chip chip-accent text-[10px]">{report.readinessLabel}</span>
              {report.candidate.autoPicked ? <span className="chip text-[10px]">auto-matched track</span> : null}
            </div>
            <h1 className="mt-2.5 text-[clamp(1.6rem,3.4vw,2.3rem)] font-extrabold leading-tight tracking-[-0.04em] text-white">
              {report.candidate.name ?? "Resume report"}
              <span className="text-white/30"> · </span>
              <span className="text-accent">{report.candidate.targetRoleTitle}</span>
            </h1>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-white/60">{report.headline}</p>

            <div className="mt-4 flex flex-wrap gap-2">
              <span className="chip">{report.candidate.levelLabel}</span>
              <span className="chip">{report.candidate.years} yr exp detected</span>
              <span className="chip">{report.stats.skillCount} skills found</span>
              <span className="chip">
                {report.candidate.email ?? "no email parsed"}
              </span>
              {report.candidate.links.slice(0, 1).map((link) => (
                <a
                  key={link}
                  href={link}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="chip transition hover:border-accent/40 hover:text-accent-soft"
                >
                  {link.replace(/^https?:\/\//, "").slice(0, 28)} ↗
                </a>
              ))}
            </div>

            <div className="no-print mt-5 flex flex-wrap gap-2">
              <button type="button" onClick={() => setTab("roadmap")} className="btn-primary text-[12.5px]">
                Open my roadmap →
              </button>
              <button type="button" onClick={copyLink} className="btn-ghost">
                {copied ? "Link copied ✓" : "Share report"}
              </button>
              <button type="button" onClick={() => window.print()} className="btn-ghost">
                Export / print
              </button>
              <Link href="/#analyzer" className="btn-ghost">
                Re-run with a new resume
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-5 lg:flex-col lg:items-end lg:justify-between">
            <div className="text-center lg:text-right">
              <ScoreRing score={report.scores.overall} caption="readiness" size={148} />
              <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">
                best fit {bestMatch?.match ?? 0}%
              </p>
            </div>
            <div className="w-full max-w-[190px] space-y-2">
              <div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-white/45">Roadmap progress</span>
                  <span className="font-mono text-white/70">
                    {completed}/{tasks.length}
                  </span>
                </div>
                <div className="mt-1">
                  <ScoreBar score={progress} tone="mint" />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-white/45">ATS score</span>
                  <span className="font-mono text-white/70">{report.scores.ats}</span>
                </div>
                <div className="mt-1">
                  <ScoreBar score={report.scores.ats} tone="accent" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/8 bg-white/[0.02] px-5 py-2.5">
          <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-white/30">{report.engine}</p>
        </div>
      </div>

      {saveError ? (
        <p className="no-print mt-3 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-[12px] text-rose">{saveError}</p>
      ) : null}

      {/* Tabs */}
      <div className="no-print sticky top-16 z-30 mt-5 -mx-1 rounded-2xl border border-white/8 bg-ink-950/85 px-1 py-1 backdrop-blur-xl">
        <div className="flex gap-1 overflow-x-auto">
          {TABS.map((entry) => (
            <button
              key={entry.id}
              type="button"
              onClick={() => setTab(entry.id)}
              aria-selected={tab === entry.id}
              role="tab"
              className={`shrink-0 rounded-xl px-3.5 py-2 text-[12.5px] font-semibold transition ${
                tab === entry.id ? "bg-accent/15 text-accent-soft" : "text-white/50 hover:bg-white/5 hover:text-white/85"
              }`}
            >
              {entry.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 space-y-4">
        {tab === "overview" ? (
          <>
            <Panel>
              <p className="label">Agent verdict</p>
              <p className="mt-2 text-[13.5px] leading-relaxed text-white/72">{report.summary}</p>
              <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-5">
                {[
                  { label: "Words", value: report.stats.words },
                  { label: "Bullets", value: report.stats.bullets },
                  { label: "Quantified", value: report.stats.quantifiedAchievements },
                  { label: "Skills", value: report.stats.skillCount },
                  { label: "Sections", value: `${report.stats.sectionsFound}/7` },
                ].map((stat) => (
                  <div key={stat.label} className="card-flat px-3 py-2.5">
                    <p className="text-[15px] font-bold text-white">{stat.value}</p>
                    <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-white/38">{stat.label}</p>
                  </div>
                ))}
              </div>
            </Panel>

            <div className="grid gap-4 lg:grid-cols-2">
              <Panel>
                <div className="flex items-center justify-between">
                  <p className="label">Score breakdown</p>
                  <span className="font-mono text-[10px] text-white/35">weighted</span>
                </div>
                <div className="mt-4 space-y-3.5">
                  {[
                    { key: "ATS parseability", value: report.scores.ats, weight: "22%" },
                    { key: "Impact of bullets", value: report.scores.impact, weight: "22%" },
                    { key: "Role skill coverage", value: report.scores.skills, weight: "24%" },
                    { key: "Project proof", value: report.scores.projects, weight: "14%" },
                    { key: "Experience signal", value: report.scores.experience, weight: "10%" },
                    { key: "Clarity & structure", value: report.scores.clarity, weight: "8%" },
                  ].map((row) => (
                    <div key={row.key}>
                      <div className="flex items-center justify-between text-[12px]">
                        <span className="text-white/65">{row.key}</span>
                        <span className="font-mono text-white/50">
                          {row.value} <span className="text-white/25">· {row.weight}</span>
                        </span>
                      </div>
                      <div className="mt-1.5">
                        <ScoreBar
                          score={row.value}
                          tone={row.value >= 74 ? "accent" : row.value >= 58 ? "sky" : "rose"}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel>
                <div className="flex items-center justify-between">
                  <p className="label">ATS audit</p>
                  <span className="font-mono text-[10px] text-white/35">
                    {report.atsFindings.filter((finding) => finding.status === "pass").length}/{report.atsFindings.length} pass
                  </span>
                </div>
                <div className="mt-3 space-y-1.5">
                  {report.atsFindings.map((finding) => {
                    const meta = STATUS_META[finding.status];
                    return (
                      <div key={finding.label} className="flex items-start gap-2.5 rounded-lg px-2 py-1.5 hover:bg-white/[0.03]">
                        <span className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border text-[10px] font-bold ${meta.className}`}>
                          {meta.icon}
                        </span>
                        <div className="min-w-0">
                          <p className="text-[12.5px] font-medium text-white/80">{finding.label}</p>
                          <p className="text-[11px] leading-relaxed text-white/38">{finding.note}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Panel>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <Panel>
                <p className="label">What already works</p>
                <ul className="mt-3 space-y-2.5">
                  {report.strengths.length ? (
                    report.strengths.map((strength) => (
                      <li key={strength} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-white/65">
                        <span className="mt-0.5 text-[11px] text-accent">✓</span>
                        {strength}
                      </li>
                    ))
                  ) : (
                    <li className="text-[12.5px] text-white/45">
                      Not much is evidenced yet — phase 1 of the roadmap is designed for exactly this situation.
                    </li>
                  )}
                </ul>
              </Panel>
              <Panel>
                <p className="label">What is costing you interviews</p>
                <ul className="mt-3 space-y-2.5">
                  {report.gaps.map((gap) => (
                    <li key={gap.title} className="rounded-xl border border-white/8 bg-white/[0.02] p-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-[12.5px] font-semibold text-white/85">{gap.title}</p>
                        <span className={`shrink-0 rounded-full border px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.1em] ${SEVERITY_META[gap.severity]}`}>
                          {gap.severity}
                        </span>
                      </div>
                      <p className="mt-1 text-[11.5px] leading-relaxed text-white/45">{gap.detail}</p>
                    </li>
                  ))}
                </ul>
              </Panel>
            </div>

            <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
              <Panel>
                <p className="label">Skill map vs {report.candidate.targetRoleTitle}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {report.skills.detected.length ? (
                    report.skills.detected.map((skill) => (
                      <span key={skill.name} className="chip">
                        {skill.name}
                      </span>
                    ))
                  ) : (
                    <span className="text-[12.5px] text-white/45">No recognised technologies yet.</span>
                  )}
                </div>
                {report.skills.gaps.length ? (
                  <>
                    <p className="label mt-5">Missing requirements, ranked</p>
                    <div className="mt-2 space-y-1.5">
                      {report.skills.gaps.map((gap) => (
                        <div key={gap.skill} className="flex items-center gap-2.5 rounded-lg border border-white/8 bg-white/[0.02] px-2.5 py-2">
                          <span
                            className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                              gap.priority === "critical" ? "bg-rose" : gap.priority === "high" ? "bg-amber-300" : "bg-sky"
                            }`}
                          />
                          <span className="text-[12.5px] font-medium text-white/85">{gap.skill}</span>
                          <span className="ml-auto font-mono text-[9px] uppercase tracking-[0.1em] text-white/35">
                            {gap.priority}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : null}
              </Panel>

              <Panel>
                <p className="label">Quick wins — do these today</p>
                <ol className="mt-3 space-y-2.5">
                  {report.quickWins.map((win, index) => (
                    <li key={win} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-white/65">
                      <span className="mt-0.5 grid h-4.5 w-4.5 shrink-0 place-items-center rounded-md border border-accent/25 bg-accent/10 font-mono text-[9.5px] text-accent">
                        {index + 1}
                      </span>
                      {win}
                    </li>
                  ))}
                </ol>
                <div className="mt-5 border-t border-white/8 pt-3.5">
                  <p className="label">Agent trace</p>
                  <div className="mt-2 space-y-1.5">
                    {report.agentSteps.map((step) => (
                      <div key={step.name} className="flex items-start gap-2">
                        <span className="mt-1 text-[9px] text-accent">●</span>
                        <div>
                          <p className="text-[11.5px] font-medium text-white/72">{step.name}</p>
                          <p className="text-[10.5px] leading-relaxed text-white/35">{step.detail}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Panel>
            </div>
          </>
        ) : null}

        {tab === "roadmap" ? (
          <>
            <Panel className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="label">Your placement roadmap</p>
                <h2 className="mt-1.5 text-[18px] font-bold tracking-[-0.025em] text-white">
                  {report.roadmap.length} phases · {tasks.length} tracked tasks
                </h2>
                <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-white/45">
                  Sequenced by hiring impact. Tick tasks as you finish them — progress is saved to this report.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-36">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-white/45">Complete</span>
                    <span className="font-mono text-white/75">{progress}%</span>
                  </div>
                  <div className="mt-1.5">
                    <ScoreBar score={progress} tone="mint" />
                  </div>
                </div>
              </div>
            </Panel>

            {report.roadmap.map((phase) => {
              const rows = rowsByPhase.get(phase.index) ?? [];
              if (!rows.length) return null;
              return <PhaseTasks key={phase.index} phase={phase} rows={rows} state={state} pending={pending} onToggle={toggle} />;
            })}

            <Panel>
              <p className="label">How to use this plan</p>
              <div className="mt-2 grid gap-3 sm:grid-cols-3">
                {[
                  "Never work two phases at once — finish the phase outcome before moving on.",
                  "If a week slips, cut scope, not the cadence. Keep shipping something public.",
                  "Re-run the analysis every 3 weeks and compare the score — that's your progress metric.",
                ].map((tip) => (
                  <p key={tip} className="text-[12px] leading-relaxed text-white/50">
                    <span className="mr-1.5 text-accent">→</span>
                    {tip}
                  </p>
                ))}
              </div>
            </Panel>
          </>
        ) : null}

        {tab === "roles" ? (
          <>
            <Panel>
              <p className="label">Role fit analysis</p>
              <h2 className="mt-1.5 text-[18px] font-bold tracking-[-0.025em] text-white">
                Where your resume is strongest today
              </h2>
              <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-white/45">
                Scored from evidenced skills only. A low match on a track is not a rejection — it is a distance signal
                you can close.
              </p>
            </Panel>
            <div className="grid gap-3 sm:grid-cols-2">
              {report.roleMatches.map((match) => (
                <div key={match.slug} className="card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-[15.5px] font-bold tracking-[-0.02em] text-white">{match.title}</h3>
                        {match.slug === report.candidate.targetRoleSlug ? (
                          <span className="chip chip-accent text-[9px]">target</span>
                        ) : null}
                      </div>
                      <p className="mt-1 font-mono text-[10.5px] uppercase tracking-[0.1em] text-white/35">
                        {match.demand} demand · {match.salaryIndia}
                      </p>
                    </div>
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-[14px] font-bold text-white">
                      {match.match}
                    </span>
                  </div>
                  <div className="mt-3">
                    <ScoreBar score={match.match} tone={match.match >= 70 ? "accent" : match.match >= 50 ? "sky" : "rose"} />
                  </div>
                  <p className="mt-2.5 text-[12px] leading-relaxed text-white/48">{match.why}</p>
                  {match.matchedSkills.length ? (
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {match.matchedSkills.slice(0, 5).map((skill) => (
                        <span key={skill} className="chip chip-accent text-[10px]">
                          {skill}
                        </span>
                      ))}
                      {match.missingSkills.slice(0, 3).map((skill) => (
                        <span key={skill} className="chip border-rose/25 bg-rose/8 text-[10px] text-rose/90">
                          ✕ {skill}
                        </span>
                      ))}
                    </div>
                  ) : null}
                  <div className="mt-3 flex items-center justify-between border-t border-white/8 pt-2.5">
                    <Link href={`/roles/${match.slug}`} className="text-[11.5px] font-semibold text-accent/85 hover:text-accent">
                      Open track roadmap →
                    </Link>
                    <Link
                      href={`/?role=${match.slug}#analyzer`}
                      className="text-[11px] text-white/40 transition hover:text-white/80"
                    >
                      Re-analyze for this role
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : null}

        {tab === "interview" ? (
          <>
            <Panel>
              <p className="label">Interview preparation</p>
              <h2 className="mt-1.5 text-[18px] font-bold tracking-[-0.025em] text-white">
                The question areas {report.candidate.targetRoleTitle} panels actually probe
              </h2>
              <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-white/45">
                Answer out loud, record yourself, and keep each answer under 90 seconds. Three rounds of this beats
                passive revision.
              </p>
            </Panel>
            <div className="grid gap-3 sm:grid-cols-2">
              {report.interviewPrep.map((topic, index) => (
                <details key={topic.topic} open={index === 0} className="card group overflow-hidden">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-5">
                    <div className="flex items-center gap-3">
                      <span className="grid h-6 w-6 place-items-center rounded-lg border border-accent/25 bg-accent/10 font-mono text-[10px] text-accent">
                        {index + 1}
                      </span>
                      <span className="text-[14px] font-semibold text-white">{topic.topic}</span>
                    </div>
                    <span aria-hidden="true" className="text-white/30 transition group-open:rotate-45">＋</span>
                  </summary>
                  <div className="border-t border-white/8 px-5 py-3.5">
                    <ul className="space-y-2">
                      {topic.questions.map((question) => (
                        <li key={question} className="flex items-start gap-2 text-[12.5px] leading-relaxed text-white/60">
                          <span className="mt-1 text-[9px] text-accent">▸</span>
                          {question}
                        </li>
                      ))}
                    </ul>
                  </div>
                </details>
              ))}
            </div>
            <Panel>
              <p className="label">Prep resources</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {report.resources.map((resource) => (
                  <a
                    key={resource.url}
                    href={resource.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="btn-ghost text-[11.5px]"
                  >
                    {resource.label} <span aria-hidden="true">↗</span>
                  </a>
                ))}
              </div>
            </Panel>
          </>
        ) : null}

        {tab === "portfolio" ? (
          <>
            <Panel>
              <p className="label">Portfolio plays</p>
              <h2 className="mt-1.5 text-[18px] font-bold tracking-[-0.025em] text-white">
                Two projects that convert for {report.candidate.targetRoleTitle}
              </h2>
              <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-white/45">
                Build these in phase 2 of your roadmap. Each one needs a public link, a decision-focused README, and a
                90-second demo.
              </p>
            </Panel>
            <div className="grid gap-3 sm:grid-cols-2">
              {report.projects.map((project) => (
                <div key={project.title} className="card flex flex-col p-5">
                  <h3 className="text-[15px] font-bold tracking-[-0.02em] text-white">{project.title}</h3>
                  <p className="mt-2 text-[12.5px] leading-relaxed text-white/55">{project.summary}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {project.stack.map((item) => (
                      <span key={item} className="chip text-[10.5px]">{item}</span>
                    ))}
                  </div>
                  <p className="mt-3 border-t border-white/8 pt-3 text-[11.5px] leading-relaxed text-accent/75">
                    Why it converts: {project.impact}
                  </p>
                </div>
              ))}
            </div>
            <Panel>
              <p className="label">Make it verifiable</p>
              <div className="mt-2 grid gap-3 sm:grid-cols-3">
                {[
                  "Deploy publicly and put the live URL in your resume header, not just GitHub.",
                  "README structure: problem → demo → architecture → decisions → measured result.",
                  "Add one failure story per project — panels love hearing what broke and how you fixed it.",
                ].map((tip) => (
                  <p key={tip} className="text-[12px] leading-relaxed text-white/50">
                    <span className="mr-1.5 text-accent">✓</span>
                    {tip}
                  </p>
                ))}
              </div>
            </Panel>
          </>
        ) : null}
      </div>

      <div className="no-print mt-8 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/8 bg-white/[0.025] px-5 py-4">
        <div>
          <p className="text-[13px] font-semibold text-white/85">Ready to re-check?</p>
          <p className="text-[11.5px] text-white/40">Update your resume, re-run the agent, and watch the score move.</p>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={() => window.print()} className="btn-ghost">
            Save as PDF
          </button>
          <Link href="/#analyzer" className="btn-primary text-[12.5px]">
            Run a new analysis →
          </Link>
        </div>
      </div>
      <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-[0.14em] text-white/20">
        report id {publicId}
      </p>
    </div>
  );
}
