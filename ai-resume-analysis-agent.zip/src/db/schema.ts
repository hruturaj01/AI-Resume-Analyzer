import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type { AnalysisReport } from "@/lib/types";

export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  publicId: text("public_id").notNull().unique(),
  candidateName: text("candidate_name"),
  targetRole: text("target_role").notNull(),
  targetRoleTitle: text("target_role_title").notNull(),
  level: text("level").notNull(),
  weeks: integer("weeks").notNull().default(12),
  overallScore: integer("overall_score").notNull(),
  atsScore: integer("ats_score").notNull(),
  readiness: text("readiness").notNull(),
  resumeText: text("resume_text").notNull(),
  fileName: text("file_name"),
  report: jsonb("report").$type<AnalysisReport>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const roadmapTasks = pgTable("roadmap_tasks", {
  id: serial("id").primaryKey(),
  analysisId: integer("analysis_id")
    .notNull()
    .references(() => analyses.id, { onDelete: "cascade" }),
  phaseIndex: integer("phase_index").notNull(),
  taskIndex: integer("task_index").notNull(),
  title: text("title").notNull(),
  done: boolean("done").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type AnalysisRow = typeof analyses.$inferSelect;
export type RoadmapTaskRow = typeof roadmapTasks.$inferSelect;
